export interface Company {
  name: string;
  address: string;
  phone: string;
  email: string;
  gstin?: string;
  logo?: string;
}

export interface Client {
  name: string;
  address: string;
  phone: string;
  email: string;
  gstin?: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
  gstRate?: number;
  gstAmount?: number;
}

export interface Invoice {
  id: string;
  type: 'gst' | 'normal' | 'proforma';
  invoiceNumber: string;
  date: string;
  dueDate: string;
  daysUntilDue: number;
  company: Company;
  client: Client;
  items: InvoiceItem[];
  subtotal: number;
  gstTotal?: number;
  total: number;
  paymentStatus: 'pending' | 'paid' | 'partially_paid';
  paymentMode: string;
  notes: string;
  template: number;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentVoucher {
  id: string;
  type: 'payment' | 'advance' | 'receipt';
  voucherNumber: string;
  date: string;
  company: Company;
  client: Client;
  amount: number;
  totalAmount?: number;
  advancePayment?: number;
  remainingBalance?: number;
  paymentMode: string;
  reference: string;
  description: string;
  status: 'pending' | 'paid' | 'cancelled';
  template: number;
  createdAt: string;
  updatedAt: string;
}

export interface BalanceSheet {
  id: string;
  period: string;
  startDate: string;
  endDate: string;
  company: Company;
  assets: {
    current: { [key: string]: number };
    fixed: { [key: string]: number };
  };
  liabilities: {
    current: { [key: string]: number };
    longTerm: { [key: string]: number };
  };
  equity: { [key: string]: number };
  createdAt: string;
  updatedAt: string;
}
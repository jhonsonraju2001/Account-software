export interface RentalDay {
  id: string;
  date: string;
  driverName: string;
  carNumber: string;
  reportingPlace: string;
  startingKm: number;
  closingKm: number;
  totalKm: number;
  startingTime: string;
  closingTime: string;
  totalHours: number;
  dailyRate: number;
  extraKmRate: number;
  extraHourRate: number;
  extraKm: number;
  extraHours: number;
  extraKmCharges: number;
  extraHourCharges: number;
  dayTotal: number;
}

export interface CarRentalBill {
  id: string;
  billNumber: string;
  date: string;
  company: {
    name: string;
    address: string;
    phone: string;
    email: string;
    logo?: string;
  };
  client: {
    name: string;
    address: string;
    phone: string;
    email: string;
  };
  bookedBy: string;
  remarks?: string;
  rentalDays: RentalDay[];
  charges: {
    subtotal: number;
    extraCharges: number;
    totalAmount: number;
  };
  paymentMode: string;
  status: 'pending' | 'paid' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}
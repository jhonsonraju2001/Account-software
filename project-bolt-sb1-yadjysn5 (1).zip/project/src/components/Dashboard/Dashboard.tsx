import React from 'react';
import { FileText, Receipt, CreditCard, TrendingUp, AlertCircle, Car } from 'lucide-react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { Invoice, PaymentVoucher } from '../../types/invoice';
import { CarRentalBill } from '../../types/carRental';

interface DashboardProps {
  onSectionChange: (section: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onSectionChange }) => {
  const [invoices] = useLocalStorage<Invoice[]>('invoices', []);
  const [vouchers] = useLocalStorage<PaymentVoucher[]>('vouchers', []);
  const [carRentalBills] = useLocalStorage<CarRentalBill[]>('carRentalBills', []);

  const gstInvoices = invoices.filter(inv => inv.type === 'gst');
  const normalBills = invoices.filter(inv => inv.type === 'normal');
  const pendingInvoices = invoices.filter(inv => inv.paymentStatus === 'pending');
  const totalRevenue = invoices
    .filter(inv => inv.paymentStatus === 'paid')
    .reduce((sum, inv) => sum + inv.total, 0);

  const stats = [
    {
      title: 'GST Invoices',
      value: gstInvoices.length,
      icon: FileText,
      color: 'bg-[#3f7a12]',
      action: () => onSectionChange('gst-invoice-list')
    },
    {
      title: 'Normal Bills',
      value: normalBills.length,
      icon: Receipt,
      color: 'bg-[#3f7a12]',
      action: () => onSectionChange('normal-bill-list')
    },
    {
      title: 'Payment Vouchers',
      value: vouchers.length,
      icon: CreditCard,
      color: 'bg-[#3f7a12]',
      action: () => onSectionChange('voucher-list')
    },
    {
      title: 'Car Rental Bills',
      value: carRentalBills.length,
      icon: Car,
      color: 'bg-[#3f7a12]',
      action: () => onSectionChange('car-rental-list')
    },
    {
      title: 'Total Revenue',
      value: `₹${totalRevenue.toLocaleString('en-IN')}`,
      icon: TrendingUp,
      color: 'bg-[#3f7a12]',
      action: () => onSectionChange('balance-sheet')
    }
  ];

  return (
    <div className="p-4 lg:p-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4 lg:gap-6 mb-6 lg:mb-8">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-4 lg:p-6 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={stat.action}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-lg lg:text-2xl font-bold text-gray-900 mt-1 lg:mt-2">{stat.value}</p>
              </div>
              <div className={`p-2 lg:p-3 rounded-full ${stat.color}`}>
                <stat.icon className="w-5 h-5 lg:w-6 lg:h-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-4 lg:p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Invoices</h3>
          <div className="space-y-3">
            {invoices.slice(0, 5).map((invoice) => (
              <div key={invoice.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-gray-50 rounded-lg space-y-2 sm:space-y-0">
                <div>
                  <p className="font-medium text-gray-800">{invoice.invoiceNumber}</p>
                  <p className="text-sm text-gray-600">{invoice.client.name}</p>
                </div>
                <div className="text-left sm:text-right">
                  <p className="font-medium text-gray-800">₹{invoice.total.toLocaleString('en-IN')}</p>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    invoice.paymentStatus === 'paid' 
                      ? 'bg-green-100 text-green-800' 
                      : invoice.paymentStatus === 'partially_paid'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {invoice.paymentStatus.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 lg:p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Pending Payments</h3>
          <div className="space-y-3">
            {pendingInvoices.slice(0, 5).map((invoice) => (
              <div key={invoice.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-red-50 rounded-lg space-y-2 sm:space-y-0">
                <div className="flex items-center sm:flex-1">
                  <AlertCircle className="w-5 h-5 text-red-500 mr-3" />
                  <div>
                    <p className="font-medium text-gray-800">{invoice.invoiceNumber}</p>
                    <p className="text-sm text-gray-600">{invoice.client.name}</p>
                  </div>
                </div>
                <div className="text-left sm:text-right ml-8 sm:ml-0">
                  <p className="font-medium text-gray-800">₹{invoice.total.toLocaleString('en-IN')}</p>
                  <p className="text-xs text-red-600">{invoice.daysUntilDue} days</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 lg:mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <button
          onClick={() => onSectionChange('create-gst-invoice')}
          className="bg-[#3f7a12] hover:bg-[#2d5a0c] text-white font-medium py-3 px-4 lg:px-6 rounded-lg transition-colors text-sm lg:text-base"
        >
          <span className="hidden sm:inline">Create GST Invoice</span>
          <span className="sm:hidden">GST Invoice</span>
        </button>
        <button
          onClick={() => onSectionChange('create-normal-bill')}
          className="bg-[#3f7a12] hover:bg-[#2d5a0c] text-white font-medium py-3 px-4 lg:px-6 rounded-lg transition-colors text-sm lg:text-base"
        >
          <span className="hidden sm:inline">Create Normal Bill</span>
          <span className="sm:hidden">Normal Bill</span>
        </button>
        <button
          onClick={() => onSectionChange('create-voucher')}
          className="bg-[#3f7a12] hover:bg-[#2d5a0c] text-white font-medium py-3 px-4 lg:px-6 rounded-lg transition-colors text-sm lg:text-base"
        >
          <span className="hidden sm:inline">Create Voucher</span>
          <span className="sm:hidden">Voucher</span>
        </button>
        <button
          onClick={() => onSectionChange('create-car-rental')}
          className="bg-[#3f7a12] hover:bg-[#2d5a0c] text-white font-medium py-3 px-4 lg:px-6 rounded-lg transition-colors text-sm lg:text-base"
        >
          <span className="hidden sm:inline">Create Car Rental Bill</span>
          <span className="sm:hidden">Car Rental</span>
        </button>
      </div>
    </div>
  );
};

export { Dashboard };
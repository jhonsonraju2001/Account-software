import React, { useState } from 'react';
import { Eye, CreditCard as Edit, Trash2, Filter, FileSpreadsheet, Car } from 'lucide-react';
import { CarRentalBill } from '../../types/carRental';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { formatDate } from '../../utils/dateUtils';
import { CarRentalPreview } from '../CarRental/CarRentalPreview';

interface CarRentalListProps {
  rentals: CarRentalBill[];
  onDelete: (id: string) => void;
  onBack?: () => void;
  onEdit?: (bill: CarRentalBill) => void;
}

const CarRentalList: React.FC<CarRentalListProps> = ({ rentals, onDelete, onBack, onEdit }) => {
  const [, setCarRentalBills] = useLocalStorage<CarRentalBill[]>('carRentalBills', []);
  const [selectedBill, setSelectedBill] = useState<CarRentalBill | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterMonth, setFilterMonth] = useState<string>('all');

  const filteredBills = rentals
    .filter(bill => {
      if (filterStatus === 'all') return true;
      return bill.status === filterStatus;
    })
    .filter(bill => {
      if (!searchTerm) return true;
      const search = searchTerm.toLowerCase();
      return (
        bill.billNumber.toLowerCase().includes(search) ||
        bill.client.name.toLowerCase().includes(search) ||
        bill.client.phone.includes(search) ||
        bill.rental.carNumber.toLowerCase().includes(search) ||
        bill.rental.driverName.toLowerCase().includes(search)
      );
    })
    .filter(bill => {
      if (filterMonth === 'all') return true;
      const billMonth = new Date(bill.date).toISOString().slice(0, 7); // YYYY-MM format
      return billMonth === filterMonth;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const deleteBill = (id: string) => {
    if (confirm('Are you sure you want to delete this car rental bill?')) {
      onDelete(id);
    }
  };

  const updateBillStatus = (id: string, status: 'pending' | 'paid' | 'cancelled') => {
    setCarRentalBills(rentals.map(bill =>
      bill.id === id ? { ...bill, status, updatedAt: new Date().toISOString() } : bill
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const exportToExcel = () => {
    // This would be implemented similar to other export functions
    console.log('Export car rental bills to Excel');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          {onBack && (
            <button
              onClick={onBack}
              className="px-4 py-2 bg-[#3f7a12] text-white rounded hover:bg-[#2d5a0c] transition-colors"
            >
              ← Back
            </button>
          )}
          <h2 className="text-lg lg:text-2xl font-bold text-gray-800 flex items-center">
            <Car className="w-6 h-6 mr-2 text-[#3f7a12]" />
            <span className="hidden sm:inline">Car Rental Bills</span>
            <span className="sm:hidden">Car Rentals</span>
          </h2>
        </div>
        <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search bills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-48 lg:w-64 text-sm"
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-gray-700">Month:</label>
            <input
              type="month"
              value={filterMonth === 'all' ? '' : filterMonth}
              onChange={(e) => setFilterMonth(e.target.value || 'all')}
              className="px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={exportToExcel}
            className="px-2 lg:px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition-colors inline-flex items-center text-sm"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Export to Excel</span>
            <span className="sm:hidden">Export</span>
          </button>
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="paid">Paid</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bill No</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Party</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Car Details</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Journey</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredBills.map((bill) => (
                <tr key={bill.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{bill.billNumber}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDate(bill.date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{bill.client.name}</div>
                    <div className="text-sm text-gray-500">{bill.client.phone}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{bill.rental.carNumber}</div>
                    <div className="text-sm text-gray-500">{bill.rental.driverName}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{bill.rental.totalKm} km</div>
                    <div className="text-sm text-gray-500">{bill.rental.totalHours} hrs</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    ₹{bill.charges.totalAmount.toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={bill.status}
                      onChange={(e) => updateBillStatus(bill.id, e.target.value as any)}
                      className={`text-xs px-2 py-1 rounded-full border-0 ${getStatusColor(bill.status)}`}
                    >
                      <option value="pending">Pending</option>
                      <option value="paid">Paid</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => setSelectedBill(bill)}
                      className="text-blue-600 hover:text-blue-800"
                      title="View"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {onEdit && (
                      <button
                        onClick={() => onEdit(bill)}
                        className="text-green-600 hover:text-green-800"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => deleteBill(bill.id)}
                      className="text-red-600 hover:text-red-800"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredBills.length === 0 && (
          <div className="text-center py-12">
            <Car className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <div className="text-gray-500">
              <p className="text-lg mb-2">No car rental bills found</p>
              <p>Create your first car rental bill to get started</p>
            </div>
          </div>
        )}
      </div>

      {selectedBill && (
        <CarRentalPreview
          bill={selectedBill}
          onClose={() => setSelectedBill(null)}
        />
      )}
    </div>
  );
};

export { CarRentalList };
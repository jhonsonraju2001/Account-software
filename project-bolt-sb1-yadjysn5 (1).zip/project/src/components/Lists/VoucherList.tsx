import React, { useState } from 'react';
import { Eye, CreditCard as Edit, Trash2, Filter, FileSpreadsheet } from 'lucide-react';
import { PaymentVoucher } from '../../types/invoice';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { formatDate } from '../../utils/dateUtils';
import { exportVouchersToExcel } from '../../utils/excelExport';
import { VoucherPreview } from '../Voucher/VoucherPreview';

interface VoucherListProps {
  vouchers: PaymentVoucher[];
  onDelete: (id: string) => void;
  onBack?: () => void;
  onEdit?: (voucher: PaymentVoucher) => void;
}

const VoucherList: React.FC<VoucherListProps> = ({ vouchers, onDelete, onBack, onEdit }) => {
  const [, setVouchers] = useLocalStorage<PaymentVoucher[]>('vouchers', []);
  const [selectedVoucher, setSelectedVoucher] = useState<PaymentVoucher | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>('all');

  const filteredVouchers = vouchers
    .filter(voucher => {
      if (filterType === 'all') return true;
      return voucher.type === filterType;
    })
    .filter(voucher => {
      if (filterStatus === 'all') return true;
      return voucher.status === filterStatus;
    })
    .filter(voucher => {
      if (filterMonth === 'all') return true;
      const voucherMonth = new Date(voucher.date).toISOString().slice(0, 7);
      return voucherMonth === filterMonth;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const deleteVoucher = (id: string) => {
    if (confirm('Are you sure you want to delete this voucher?')) {
      onDelete(id);
    }
  };

  const updateVoucherStatus = (id: string, status: 'pending' | 'paid' | 'cancelled') => {
    setVouchers(vouchers.map(voucher => 
      voucher.id === id ? { ...voucher, status, updatedAt: new Date().toISOString() } : voucher
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getTypeLabel = (voucherType: string) => {
    switch (voucherType) {
      case 'payment':
        return 'Payment Voucher';
      case 'advance':
        return 'Advance Payment';
      case 'receipt':
        return 'Payment Receipt';
      default:
        return 'Voucher';
    }
  };

  const getTypeColor = (voucherType: string) => {
    switch (voucherType) {
      case 'payment':
        return 'bg-orange-100 text-orange-800';
      case 'advance':
        return 'bg-blue-100 text-blue-800';
      case 'receipt':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleExportToExcel = () => {
    exportVouchersToExcel(filteredVouchers, 'payment-vouchers');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          {onBack && (
            <button
              onClick={onBack}
              className="px-4 py-2 bg-[#3f7a12] text-white rounded hover:bg-[#2d5a0c] transition-colors"
            >
              ← Back
            </button>
          )}
          <h2 className="text-lg lg:text-2xl font-bold text-gray-800">Payment Vouchers</h2>
        </div>
        <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
          <button
            onClick={handleExportToExcel}
            className="px-2 lg:px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition-colors inline-flex items-center text-sm"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Export to Excel</span>
            <span className="sm:hidden">Export</span>
          </button>
          <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <input
              type="month"
              value={filterMonth === 'all' ? '' : filterMonth}
              onChange={(e) => setFilterMonth(e.target.value || 'all')}
              className="px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Types</option>
              <option value="payment">Payment Voucher</option>
              <option value="advance">Advance Payment</option>
              <option value="receipt">Payment Receipt</option>
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="paid">Paid</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Voucher</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client/Payee</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total/Balance</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment Mode</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredVouchers.map((voucher) => (
                <tr key={voucher.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{voucher.voucherNumber}</div>
                      <div className="text-sm text-gray-500">Template {voucher.template}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{voucher.client.name}</div>
                    <div className="text-sm text-gray-500">{voucher.client.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`text-xs px-2 py-1 rounded-full ${getTypeColor(voucher.type)}`}>
                      {getTypeLabel(voucher.type)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDate(voucher.date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    ₹{voucher.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {voucher.totalAmount ? (
                      <div>
                        <div className="text-xs text-gray-500">Total: ₹{voucher.totalAmount.toLocaleString('en-IN')}</div>
                        {voucher.remainingBalance ? (
                          <div className="text-xs text-red-600">Balance: ₹{voucher.remainingBalance.toLocaleString('en-IN')}</div>
                        ) : null}
                      </div>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {voucher.paymentMode}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={voucher.status}
                      onChange={(e) => updateVoucherStatus(voucher.id, e.target.value as any)}
                      className={`text-xs px-2 py-1 rounded-full border-0 ${getStatusColor(voucher.status)}`}
                    >
                      <option value="pending">Pending</option>
                      <option value="paid">Paid</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => setSelectedVoucher(voucher)}
                      className="text-blue-600 hover:text-blue-800"
                      title="View"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => exportVouchersToExcel([voucher], `voucher-${voucher.voucherNumber}`)}
                      className="text-green-600 hover:text-green-800"
                      title="Export to Excel"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                    </button>
                    {onEdit && (
                      <button
                        onClick={() => onEdit(voucher)}
                        className="text-green-600 hover:text-green-800"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => deleteVoucher(voucher.id)}
                      className="text-red-600 hover:text-red-800"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredVouchers.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-500">
              <p className="text-lg mb-2">No vouchers found</p>
              <p>Create your first voucher to get started</p>
            </div>
          </div>
        )}
      </div>

      {selectedVoucher && (
        <VoucherPreview
          voucher={selectedVoucher}
          onClose={() => setSelectedVoucher(null)}
        />
      )}
    </div>
  );
};

export { VoucherList };
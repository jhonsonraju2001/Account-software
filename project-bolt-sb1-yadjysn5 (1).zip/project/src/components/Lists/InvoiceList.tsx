import React, { useState } from 'react';
import { Eye, CreditCard as Edit, Trash2, Download, Filter, FileSpreadsheet } from 'lucide-react';
import { Invoice } from '../../types/invoice';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { formatDate } from '../../utils/dateUtils';
import { exportInvoicesToExcel, exportItemizedInvoiceToExcel } from '../../utils/excelExport';
import { InvoicePreview } from '../Invoice/InvoicePreview';

interface InvoiceListProps {
  invoices: Invoice[];
  onDelete: (id: string) => void;
  onBack?: () => void;
  onEdit?: (invoice: Invoice) => void;
}

const InvoiceList: React.FC<InvoiceListProps> = ({ invoices, onDelete, onBack, onEdit }) => {
  const [, setInvoices] = useLocalStorage<Invoice[]>('invoices', []);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>('all');

  const filteredInvoices = invoices
    .filter(invoice => {
      if (filterStatus === 'all') return true;
      return invoice.paymentStatus === filterStatus;
    })
    .filter(invoice => {
      if (filterMonth === 'all') return true;
      const invoiceMonth = new Date(invoice.date).toISOString().slice(0, 7);
      return invoiceMonth === filterMonth;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const deleteInvoice = (id: string) => {
    if (confirm('Are you sure you want to delete this invoice?')) {
      onDelete(id);
    }
  };

  const updatePaymentStatus = (id: string, status: 'pending' | 'paid' | 'partially_paid') => {
    setInvoices(invoices.map(invoice => 
      invoice.id === id ? { ...invoice, paymentStatus: status, updatedAt: new Date().toISOString() } : invoice
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'partially_paid':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-red-100 text-red-800';
    }
  };

  const getTypeLabel = (invoiceType: string) => {
    switch (invoiceType) {
      case 'gst':
        return 'GST Invoice';
      case 'proforma':
        return 'Proforma Invoice';
      default:
        return 'Normal Bill';
    }
  };

  const handleExportToExcel = () => {
    exportInvoicesToExcel(filteredInvoices, 'invoices');
  };
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          {onBack && (
            <button
              onClick={onBack}
              className="px-4 py-2 bg-[#3f7a12] text-white rounded hover:bg-[#2d5a0c] transition-colors"
            >
              ← Back
            </button>
          )}
          <h2 className="text-lg lg:text-2xl font-bold text-gray-800">
            Invoices
          </h2>
        </div>
        <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
          <button
            onClick={handleExportToExcel}
            className="px-2 lg:px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition-colors inline-flex items-center text-sm"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Export to Excel</span>
            <span className="sm:hidden">Export</span>
          </button>
          <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <input
              type="month"
              value={filterMonth === 'all' ? '' : filterMonth}
              onChange={(e) => setFilterMonth(e.target.value || 'all')}
              className="px-2 lg:px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-2 lg:px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="partially_paid">Partially Paid</option>
              <option value="paid">Paid</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Invoice</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Due</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredInvoices.map((invoice) => (
                <tr key={invoice.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{invoice.invoiceNumber}</div>
                      <div className="text-sm text-gray-500">Template {invoice.template}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{invoice.client.name}</div>
                    <div className="text-sm text-gray-500">{invoice.client.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-medium text-gray-900">
                      {getTypeLabel(invoice.type)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDate(invoice.date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{formatDate(invoice.dueDate)}</div>
                    <div className={`text-sm ${invoice.daysUntilDue < 0 ? 'text-red-600' : 'text-gray-500'}`}>
                      {invoice.daysUntilDue} days
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    ₹{invoice.total.toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={invoice.paymentStatus}
                      onChange={(e) => updatePaymentStatus(invoice.id, e.target.value as any)}
                      className={`text-xs px-2 py-1 rounded-full border-0 ${getStatusColor(invoice.paymentStatus)}`}
                    >
                      <option value="pending">Pending</option>
                      <option value="partially_paid">Partially Paid</option>
                      <option value="paid">Paid</option>
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => setSelectedInvoice(invoice)}
                      className="text-blue-600 hover:text-blue-800"
                      title="View"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                   <button
                     onClick={() => exportItemizedInvoiceToExcel(invoice)}
                     className="text-green-600 hover:text-green-800"
                     title="Export to Excel"
                   >
                     <FileSpreadsheet className="w-4 h-4" />
                   </button>
                    {onEdit && (
                      <button
                        onClick={() => onEdit(invoice)}
                        className="text-green-600 hover:text-green-800"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => deleteInvoice(invoice.id)}
                      className="text-red-600 hover:text-red-800"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredInvoices.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-500">
              <p className="text-lg mb-2">No invoices found</p>
              <p>Create your first invoice to get started</p>
            </div>
          </div>
        )}
      </div>

      {selectedInvoice && (
        <InvoicePreview
          invoice={selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
        />
      )}
    </div>
  );
};

export { InvoiceList };
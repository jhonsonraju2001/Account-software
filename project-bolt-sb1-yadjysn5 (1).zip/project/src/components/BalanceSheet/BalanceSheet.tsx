import React, { useState } from 'react';
import { Save, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { BalanceSheet as BalanceSheetType } from '../../types/invoice';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { formatDate } from '../../utils/dateUtils';

const BalanceSheet: React.FC = () => {
  const [balanceSheets, setBalanceSheets] = useLocalStorage<BalanceSheetType[]>('balanceSheets', []);
  const [companyDefaults] = useLocalStorage('companyDefaults', {
    name: '',
    address: '',
    phone: '',
    email: '',
    logo: ''
  });
  const [showForm, setShowForm] = useState(false);
  
  const [company, setCompany] = useState(companyDefaults);

  const [balanceData, setBalanceData] = useState({
    period: '',
    startDate: '',
    endDate: ''
  });

  const [assets, setAssets] = useState({
    current: {
      'Cash in Hand': 0,
      'Bank Balance': 0,
      'Accounts Receivable': 0,
      'Inventory': 0,
      'Prepaid Expenses': 0
    },
    fixed: {
      'Land & Building': 0,
      'Machinery & Equipment': 0,
      'Furniture & Fixtures': 0,
      'Vehicles': 0,
      'Investments': 0
    }
  });

  const [liabilities, setLiabilities] = useState({
    current: {
      'Accounts Payable': 0,
      'Short-term Loans': 0,
      'Accrued Expenses': 0,
      'Tax Payable': 0
    },
    longTerm: {
      'Long-term Loans': 0,
      'Mortgage Payable': 0,
      'Deferred Tax': 0
    }
  });

  const [equity, setEquity] = useState({
    'Share Capital': 0,
    'Retained Earnings': 0,
    'Reserves': 0
  });

  const calculateTotal = (obj: any): number => {
    return Object.values(obj).reduce((sum: number, val: any) => {
      if (typeof val === 'object') {
        return sum + calculateTotal(val);
      }
      return sum + (val as number);
    }, 0);
  };

  const totalAssets = calculateTotal(assets);
  const totalLiabilities = calculateTotal(liabilities);
  const totalEquity = calculateTotal(equity);
  const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newBalanceSheet: BalanceSheetType = {
      id: Date.now().toString(),
      period: balanceData.period,
      startDate: balanceData.startDate,
      endDate: balanceData.endDate,
      company,
      assets,
      liabilities,
      equity,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setBalanceSheets([...balanceSheets, newBalanceSheet]);
    setShowForm(false);
    
    // Reset form
    setBalanceData({ period: '', startDate: '', endDate: '' });
    setCompany(companyDefaults);
  };

  const updateAsset = (category: 'current' | 'fixed', key: string, value: number) => {
    setAssets(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
  };

  const updateLiability = (category: 'current' | 'longTerm', key: string, value: number) => {
    setLiabilities(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
  };

  const updateEquity = (key: string, value: number) => {
    setEquity(prev => ({
      ...prev,
      [key]: value
    }));
  };

  if (showForm) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800">Create Balance Sheet</h2>
          <button
            onClick={() => setShowForm(false)}
            className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 transition-colors"
          >
            Cancel
          </button>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-6">
          {/* Company Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-700">Company Information</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                <input
                  type="text"
                  required
                  value={company.name}
                  onChange={(e) => setCompany({...company, name: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                <textarea
                  required
                  value={company.address}
                  onChange={(e) => setCompany({...company, address: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                />
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-700">Period Information</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Period</label>
                <input
                  type="text"
                  required
                  value={balanceData.period}
                  onChange={(e) => setBalanceData({...balanceData, period: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., FY 2024-25"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                  <input
                    type="date"
                    required
                    value={balanceData.startDate}
                    onChange={(e) => setBalanceData({...balanceData, startDate: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                  <input
                    type="date"
                    required
                    value={balanceData.endDate}
                    onChange={(e) => setBalanceData({...balanceData, endDate: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Assets */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-green-600">ASSETS</h3>
              
              {/* Current Assets */}
              <div>
                <h4 className="text-lg font-semibold text-gray-700 mb-3">Current Assets</h4>
                <div className="space-y-2">
                  {Object.entries(assets.current).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center">
                      <label className="text-sm text-gray-600">{key}</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={value}
                        onChange={(e) => updateAsset('current', key, parseFloat(e.target.value) || 0)}
                        className="w-32 p-1 border border-gray-300 rounded text-right"
                      />
                    </div>
                  ))}
                  <div className="flex justify-between items-center font-semibold border-t pt-2">
                    <span>Total Current Assets:</span>
                    <span>₹{calculateTotal(assets.current).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* Fixed Assets */}
              <div>
                <h4 className="text-lg font-semibold text-gray-700 mb-3">Fixed Assets</h4>
                <div className="space-y-2">
                  {Object.entries(assets.fixed).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center">
                      <label className="text-sm text-gray-600">{key}</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={value}
                        onChange={(e) => updateAsset('fixed', key, parseFloat(e.target.value) || 0)}
                        className="w-32 p-1 border border-gray-300 rounded text-right"
                      />
                    </div>
                  ))}
                  <div className="flex justify-between items-center font-semibold border-t pt-2">
                    <span>Total Fixed Assets:</span>
                    <span>₹{calculateTotal(assets.fixed).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 p-3 rounded">
                <div className="flex justify-between items-center text-lg font-bold text-green-700">
                  <span>TOTAL ASSETS:</span>
                  <span>₹{totalAssets.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>

            {/* Liabilities and Equity */}
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-red-600">LIABILITIES & EQUITY</h3>
              
              {/* Current Liabilities */}
              <div>
                <h4 className="text-lg font-semibold text-gray-700 mb-3">Current Liabilities</h4>
                <div className="space-y-2">
                  {Object.entries(liabilities.current).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center">
                      <label className="text-sm text-gray-600">{key}</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={value}
                        onChange={(e) => updateLiability('current', key, parseFloat(e.target.value) || 0)}
                        className="w-32 p-1 border border-gray-300 rounded text-right"
                      />
                    </div>
                  ))}
                  <div className="flex justify-between items-center font-semibold border-t pt-2">
                    <span>Total Current Liabilities:</span>
                    <span>₹{calculateTotal(liabilities.current).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* Long-term Liabilities */}
              <div>
                <h4 className="text-lg font-semibold text-gray-700 mb-3">Long-term Liabilities</h4>
                <div className="space-y-2">
                  {Object.entries(liabilities.longTerm).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center">
                      <label className="text-sm text-gray-600">{key}</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={value}
                        onChange={(e) => updateLiability('longTerm', key, parseFloat(e.target.value) || 0)}
                        className="w-32 p-1 border border-gray-300 rounded text-right"
                      />
                    </div>
                  ))}
                  <div className="flex justify-between items-center font-semibold border-t pt-2">
                    <span>Total Long-term Liabilities:</span>
                    <span>₹{calculateTotal(liabilities.longTerm).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              {/* Equity */}
              <div>
                <h4 className="text-lg font-semibold text-gray-700 mb-3">Equity</h4>
                <div className="space-y-2">
                  {Object.entries(equity).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center">
                      <label className="text-sm text-gray-600">{key}</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={value}
                        onChange={(e) => updateEquity(key, parseFloat(e.target.value) || 0)}
                        className="w-32 p-1 border border-gray-300 rounded text-right"
                      />
                    </div>
                  ))}
                  <div className="flex justify-between items-center font-semibold border-t pt-2">
                    <span>Total Equity:</span>
                    <span>₹{totalEquity.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              <div className="bg-red-50 p-3 rounded">
                <div className="flex justify-between items-center text-lg font-bold text-red-700">
                  <span>TOTAL LIABILITIES & EQUITY:</span>
                  <span>₹{totalLiabilitiesAndEquity.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Balance Check */}
          <div className={`p-4 rounded-lg ${
            totalAssets === totalLiabilitiesAndEquity 
              ? 'bg-green-100 border border-green-400' 
              : 'bg-red-100 border border-red-400'
          }`}>
            <div className="flex items-center justify-center">
              {totalAssets === totalLiabilitiesAndEquity ? (
                <>
                  <TrendingUp className="w-6 h-6 text-green-600 mr-2" />
                  <span className="text-green-800 font-semibold">Balance Sheet is Balanced! ✓</span>
                </>
              ) : (
                <>
                  <TrendingDown className="w-6 h-6 text-red-600 mr-2" />
                  <span className="text-red-800 font-semibold">
                    Balance Sheet is not balanced. Difference: ₹{Math.abs(totalAssets - totalLiabilitiesAndEquity).toLocaleString('en-IN')}
                  </span>
                </>
              )}
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={totalAssets !== totalLiabilitiesAndEquity}
              className="px-6 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors inline-flex items-center disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Balance Sheet
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Balance Sheet</h2>
        <button
          onClick={() => setShowForm(true)}
          className="px-6 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors inline-flex items-center"
        >
          <DollarSign className="w-4 h-4 mr-2" />
          Create Balance Sheet
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Balance Sheets</p>
              <p className="text-2xl font-bold text-gray-900">{balanceSheets.length}</p>
            </div>
            <div className="p-3 rounded-full bg-purple-500">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Period</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Range</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Assets</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {balanceSheets.map((sheet) => (
                <tr key={sheet.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {sheet.period}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {sheet.company.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDate(sheet.startDate)} - {formatDate(sheet.endDate)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    ₹{calculateTotal(sheet.assets).toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(sheet.createdAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {balanceSheets.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-500">
              <p className="text-lg mb-2">No balance sheets found</p>
              <p>Create your first balance sheet to get started</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export { BalanceSheet };
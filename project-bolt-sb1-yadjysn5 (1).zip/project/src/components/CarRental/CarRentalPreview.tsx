import React, { useState } from 'react';
import { X, Edit2, Printer, FileText } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { CarRentalBill } from '../../types/carRental';

interface CarRentalPreviewProps {
  bill: CarRentalBill;
  onClose: () => void;
  onEdit: () => void;
}

const CarRentalPreview: React.FC<CarRentalPreviewProps> = ({ bill, onClose, onEdit }) => {
  const [isDownloading, setIsDownloading] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    setIsDownloading(true);
    try {
      const element = document.getElementById('printable-content');
      if (!element) {
        alert('Error: Document not found');
        setIsDownloading(false);
        return;
      }

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgData = canvas.toDataURL('image/png');
      const pageWidth = 210;
      const pageHeight = 297;
      const imgWidth = 200;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`car-rental-${bill.billNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg w-full max-w-6xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center print:hidden">
          <h2 className="text-xl font-bold text-gray-800">Car Rental Bill</h2>
          <div className="flex space-x-2">
            <button
              onClick={onEdit}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center text-sm"
              title="Edit bill"
            >
              <Edit2 className="w-4 h-4 mr-2" />
              Edit
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors inline-flex items-center text-sm"
              title="Print bill"
            >
              <Printer className="w-4 h-4 mr-2" />
              Print
            </button>
            <button
              onClick={handleDownloadPDF}
              disabled={isDownloading}
              className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:bg-gray-400 transition-colors inline-flex items-center text-sm"
              title="Download as PDF"
            >
              <FileText className="w-4 h-4 mr-2" />
              {isDownloading ? 'Generating...' : 'PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded transition-colors"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div id="printable-content" className="bg-white">
          <div className="p-8" style={{width: '210mm', margin: '0 auto'}}>
            <div className="border-2 border-gray-800 p-8 bg-white">
              {bill.company.logo && (
                <div className="flex justify-center mb-4">
                  <img src={bill.company.logo} alt="Company Logo" className="h-20 object-contain" />
                </div>
              )}

              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-gray-800">{bill.company.name}</h1>
                <p className="text-sm text-gray-600">{bill.company.address}</p>
                <p className="text-sm text-gray-600">
                  Phone: {bill.company.phone} | Email: {bill.company.email}
                </p>
              </div>

              <div className="text-center mb-6 py-3 bg-gray-100 border-y-2 border-gray-800">
                <h2 className="text-xl font-bold">CAR RENTAL BILL</h2>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-sm"><span className="font-semibold">Bill No:</span> {bill.billNumber}</p>
                  <p className="text-sm"><span className="font-semibold">Date:</span> {bill.date}</p>
                  <p className="text-sm"><span className="font-semibold">Booked By:</span> {bill.bookedBy}</p>
                  <p className="text-sm"><span className="font-semibold">Payment:</span> {bill.paymentMode}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold mb-1">Client Details:</p>
                  <p className="text-sm font-semibold">{bill.client.name}</p>
                  <p className="text-sm">{bill.client.address}</p>
                  <p className="text-sm">{bill.client.phone}</p>
                  <p className="text-sm">{bill.client.email}</p>
                </div>
              </div>

              {bill.rentalDays.map((day, index) => (
                <div key={day.id} className="mb-6 border-2 border-gray-300 p-4">
                  <h3 className="font-bold text-gray-800 mb-3 pb-2 border-b border-gray-300">
                    Day {index + 1} - {day.date}
                  </h3>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div>
                      <p><span className="font-semibold">Driver:</span> {day.driverName}</p>
                      <p><span className="font-semibold">Car:</span> {day.carNumber}</p>
                      <p><span className="font-semibold">Location:</span> {day.reportingPlace}</p>
                    </div>
                    <div>
                      <p><span className="font-semibold">Start:</span> {day.startingTime}</p>
                      <p><span className="font-semibold">End:</span> {day.closingTime}</p>
                      <p><span className="font-semibold">Hours:</span> {day.totalHours}</p>
                    </div>
                  </div>

                  <table className="w-full text-sm mb-3">
                    <thead>
                      <tr className="bg-gray-100 border border-gray-300">
                        <th className="text-left p-2 border border-gray-300">Description</th>
                        <th className="text-right p-2 border border-gray-300">Details</th>
                        <th className="text-right p-2 border border-gray-300">Rate</th>
                        <th className="text-right p-2 border border-gray-300">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border border-gray-300">
                        <td className="p-2 border border-gray-300">Daily Rental</td>
                        <td className="text-right p-2 border border-gray-300">1 day</td>
                        <td className="text-right p-2 border border-gray-300">₹{day.dailyRate.toFixed(2)}</td>
                        <td className="text-right p-2 border border-gray-300">₹{day.dailyRate.toFixed(2)}</td>
                      </tr>
                      <tr className="border border-gray-300">
                        <td className="p-2 border border-gray-300">Kilometers</td>
                        <td className="text-right p-2 border border-gray-300">{day.startingKm} - {day.closingKm} ({day.totalKm} km)</td>
                        <td className="text-right p-2 border border-gray-300">-</td>
                        <td className="text-right p-2 border border-gray-300">-</td>
                      </tr>
                      {day.extraKm > 0 && (
                        <tr className="border border-gray-300">
                          <td className="p-2 border border-gray-300">Extra KM</td>
                          <td className="text-right p-2 border border-gray-300">{day.extraKm} km</td>
                          <td className="text-right p-2 border border-gray-300">₹{day.extraKmRate.toFixed(2)}/km</td>
                          <td className="text-right p-2 border border-gray-300">₹{day.extraKmCharges.toFixed(2)}</td>
                        </tr>
                      )}
                      {day.extraHours > 0 && (
                        <tr className="border border-gray-300">
                          <td className="p-2 border border-gray-300">Extra Hours</td>
                          <td className="text-right p-2 border border-gray-300">{day.extraHours} hrs</td>
                          <td className="text-right p-2 border border-gray-300">₹{day.extraHourRate.toFixed(2)}/hr</td>
                          <td className="text-right p-2 border border-gray-300">₹{day.extraHourCharges.toFixed(2)}</td>
                        </tr>
                      )}
                      <tr className="bg-green-50 font-semibold border border-gray-300">
                        <td colSpan={3} className="text-right p-2 border border-gray-300">Day Total:</td>
                        <td className="text-right p-2 border border-gray-300">₹{day.dayTotal.toFixed(2)}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              ))}

              <div className="border-t-2 border-gray-300 pt-4 mb-4">
                <div className="flex justify-end">
                  <div className="w-72 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-semibold">Subtotal:</span>
                      <span>₹{bill.charges.subtotal.toFixed(2)}</span>
                    </div>
                    {bill.charges.extraCharges && bill.charges.extraCharges > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="font-semibold">Extra Charges:</span>
                        <span>₹{bill.charges.extraCharges.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-lg font-bold border-t-2 border-gray-300 pt-2">
                      <span>Total Amount:</span>
                      <span className="text-[#3f7a12]">₹{bill.charges.totalAmount.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {bill.remarks && (
                <div className="mt-6 text-sm">
                  <p className="font-semibold">Remarks:</p>
                  <p className="text-gray-700">{bill.remarks}</p>
                </div>
              )}

              <div className="mt-8 pt-4 border-t border-gray-300">
                <p className="text-xs text-gray-600 text-center">
                  This is a computer-generated document and does not require a signature.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          * {
            -webkit-print-color-adjust: exact !important;
            color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          body {
            margin: 0;
            padding: 0;
          }

          .fixed {
            position: static;
          }

          .bg-black.bg-opacity-50 {
            display: none;
          }

          .rounded-lg {
            border-radius: 0;
          }

          #printable-content {
            max-width: 100%;
            padding: 0;
            margin: 0;
            box-shadow: none;
            border-radius: 0;
          }

          @page {
            size: A4;
            margin: 0;
            padding: 0;
          }
        }
      `}</style>
    </div>
  );
};

export { CarRentalPreview };

import React, { useRef, useState } from 'react';
import { Upload, X, FileText, Eye } from 'lucide-react';

interface BillFormat {
  id: string;
  name: string;
  template: string;
  createdAt: string;
}

interface BillFormatUploadProps {
  onFormatAdd: (format: BillFormat) => void;
  formats: BillFormat[];
  onFormatRemove: (id: string) => void;
}

const BillFormatUpload: React.FC<BillFormatUploadProps> = ({ 
  onFormatAdd, 
  formats, 
  onFormatRemove 
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleFileSelect = (file: File) => {
    if (!file.name.endsWith('.html') && !file.name.endsWith('.htm')) {
      alert('Please select an HTML file');
      return;
    }

    if (file.size > 1024 * 1024) { // 1MB limit
      alert('File size must be less than 1MB');
      return;
    }

    setUploading(true);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const template = e.target?.result as string;
      const format: BillFormat = {
        id: Date.now().toString(),
        name: file.name.replace(/\.[^/.]+$/, ""),
        template,
        createdAt: new Date().toISOString()
      };
      
      onFormatAdd(format);
      setUploading(false);
      
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const previewFormat = (format: BillFormat) => {
    const newWindow = window.open('', '_blank');
    if (newWindow) {
      newWindow.document.write(format.template);
      newWindow.document.close();
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Custom Bill Formats
        </label>
        <p className="text-sm text-gray-600 mb-4">
          Upload HTML templates for custom bill formats. Use placeholders like {{companyName}}, {{clientName}}, {{items}}, etc.
        </p>
        
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
            dragOver 
              ? 'border-blue-400 bg-blue-50' 
              : 'border-gray-300 hover:border-gray-400'
          }`}
          onDrop={handleDrop}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onClick={() => fileInputRef.current?.click()}
        >
          {uploading ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
              <span className="ml-2 text-gray-600">Uploading...</span>
            </div>
          ) : (
            <>
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600 mb-1">Drop HTML template here or click to browse</p>
              <p className="text-sm text-gray-500">HTML files only, max 1MB</p>
            </>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept=".html,.htm"
          onChange={handleFileInput}
          className="hidden"
        />
        
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center"
        >
          <Upload className="w-4 h-4 mr-2" />
          Upload Template
        </button>
      </div>

      {formats.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-medium text-gray-700">Uploaded Formats</h4>
          {formats.map((format) => (
            <div key={format.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <FileText className="w-5 h-5 text-blue-500 mr-3" />
                <div>
                  <p className="font-medium text-gray-800">{format.name}</p>
                  <p className="text-sm text-gray-600">
                    Uploaded on {new Date(format.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => previewFormat(format)}
                  className="p-2 text-blue-600 hover:text-blue-800"
                  title="Preview"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onFormatRemove(format.id)}
                  className="p-2 text-red-600 hover:text-red-800"
                  title="Remove"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export { BillFormatUpload };
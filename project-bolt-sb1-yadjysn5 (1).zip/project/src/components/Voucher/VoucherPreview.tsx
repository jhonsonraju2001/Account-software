import React, { useState } from 'react';
import { X, Printer, FileText, Edit2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { PaymentVoucher } from '../../types/invoice';
import { formatDate } from '../../utils/dateUtils';

interface VoucherPreviewProps {
  voucher: PaymentVoucher;
  onClose: () => void;
  onEdit?: () => void;
}

const VoucherPreview: React.FC<VoucherPreviewProps> = ({ voucher, onClose, onEdit }) => {
  const [isDownloading, setIsDownloading] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    setIsDownloading(true);
    try {
      const element = document.getElementById('voucher-printable-content');
      if (!element) {
        alert('Error: Document not found');
        setIsDownloading(false);
        return;
      }

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgData = canvas.toDataURL('image/png');
      const pageWidth = 210;
      const pageHeight = 297;
      const imgWidth = 200;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`voucher-${voucher.voucherNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const getVoucherTitle = () => {
    switch (voucher.type) {
      case 'payment':
        return 'PAYMENT VOUCHER';
      case 'advance':
        return 'ADVANCE PAYMENT VOUCHER';
      case 'receipt':
        return 'PAYMENT RECEIPT';
      default:
        return 'VOUCHER';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center print:hidden">
          <h2 className="text-xl font-bold text-gray-800">Voucher Preview</h2>
          <div className="flex space-x-2">
            {onEdit && (
              <button
                onClick={onEdit}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center text-sm"
              >
                <Edit2 className="w-4 h-4 mr-2" />
                Edit
              </button>
            )}
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors inline-flex items-center text-sm"
            >
              <Printer className="w-4 h-4 mr-2" />
              Print
            </button>
            <button
              onClick={handleDownloadPDF}
              disabled={isDownloading}
              className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:bg-gray-400 transition-colors inline-flex items-center text-sm"
            >
              <FileText className="w-4 h-4 mr-2" />
              {isDownloading ? 'Generating...' : 'PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div id="voucher-printable-content" className="p-8 bg-white">
          <div className="bg-white border-2 border-orange-500 p-8 max-w-3xl mx-auto">
            {/* Header */}
            <div className="flex justify-between items-start mb-8 pb-6 border-b-2 border-orange-500">
              <div className="flex items-center">
                {voucher.company.logo && (
                  <img 
                    src={voucher.company.logo} 
                    alt="Company Logo" 
                    className="w-16 h-16 mr-4 object-contain"
                  />
                )}
                <div>
                  <h1 className="text-2xl font-bold text-orange-600">{voucher.company.name}</h1>
                  <p className="text-gray-600 mt-1">Payment Management</p>
                </div>
              </div>
              <div className="text-right">
                <h2 className="text-xl font-bold text-gray-800 mb-2">{getVoucherTitle()}</h2>
                <p className="text-lg font-semibold text-orange-600">{voucher.voucherNumber}</p>
                <div className="mt-4 text-sm text-gray-600">
                  <p><strong>Date:</strong> {formatDate(voucher.date)}</p>
                </div>
              </div>
            </div>

            {/* Company and Client Info */}
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3 bg-orange-50 p-2 rounded">From:</h3>
                <div className="space-y-1 text-gray-700">
                  <p className="font-semibold">{voucher.company.name}</p>
                  <p>{voucher.company.address}</p>
                  <p>Phone: {voucher.company.phone}</p>
                  <p>Email: {voucher.company.email}</p>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3 bg-green-50 p-2 rounded">
                  {voucher.type === 'payment' ? 'To:' : 'From:'}
                </h3>
                <div className="space-y-1 text-gray-700">
                  <p className="font-semibold">{voucher.client.name}</p>
                  <p>{voucher.client.address}</p>
                  <p>Phone: {voucher.client.phone}</p>
                  <p>Email: {voucher.client.email}</p>
                </div>
              </div>
            </div>

            {/* Voucher Details */}
            <div className="mb-8">
              {/* Payment Breakdown */}
              {(voucher.totalAmount || voucher.advancePayment || voucher.remainingBalance) && (
                <div className="bg-blue-50 p-6 rounded-lg mb-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Payment Breakdown</h3>
                  <div className="grid grid-cols-3 gap-6">
                    {voucher.totalAmount && (
                      <div className="text-center">
                        <p className="text-sm text-gray-600 uppercase tracking-wider">Total Amount</p>
                        <p className="text-2xl font-bold text-blue-600">₹{voucher.totalAmount.toLocaleString('en-IN')}</p>
                      </div>
                    )}
                    {voucher.advancePayment && (
                      <div className="text-center">
                        <p className="text-sm text-gray-600 uppercase tracking-wider">Advance Paid</p>
                        <p className="text-2xl font-bold text-green-600">₹{voucher.advancePayment.toLocaleString('en-IN')}</p>
                      </div>
                    )}
                    {voucher.remainingBalance && (
                      <div className="text-center">
                        <p className="text-sm text-gray-600 uppercase tracking-wider">Remaining Balance</p>
                        <p className="text-2xl font-bold text-red-600">₹{voucher.remainingBalance.toLocaleString('en-IN')}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              {/* Current Payment Details */}
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="grid grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Current Payment Details</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Amount:</span>
                      <span className="font-bold text-2xl text-orange-600">₹{voucher.amount.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Mode:</span>
                      <span className="font-medium">{voucher.paymentMode}</span>
                    </div>
                    {voucher.reference && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Reference:</span>
                        <span className="font-medium">{voucher.reference}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <span className={`px-2 py-1 rounded text-sm font-medium ${
                        voucher.status === 'paid' 
                          ? 'bg-green-100 text-green-800' 
                          : voucher.status === 'cancelled'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {voucher.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Description</h3>
                  <p className="text-gray-700 leading-relaxed">{voucher.description}</p>
                </div>
              </div>
              </div>
            </div>

            {/* Amount in Words */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Amount in Words:</h3>
              <p className="text-gray-700 italic">
                {/* This would normally be converted to words, simplified for demo */}
                Rupees {voucher.amount.toLocaleString('en-IN')} Only
              </p>
            </div>

            {/* Signature Section */}
            <div className="grid grid-cols-2 gap-8 mt-12 pt-8 border-t">
              <div>
                <div className="border-t border-gray-400 pt-2 mt-16">
                  <p className="text-center font-medium">Prepared By</p>
                </div>
              </div>
              <div>
                <div className="border-t border-gray-400 pt-2 mt-16">
                  <p className="text-center font-medium">Authorized Signatory</p>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="border-t pt-4 mt-8 text-center text-gray-600">
              <p className="text-sm">Thank you for your business!</p>
              <p className="text-xs mt-2">This is a computer-generated voucher.</p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          * {
            -webkit-print-color-adjust: exact !important;
            color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          body {
            margin: 0;
            padding: 0;
          }

          .fixed {
            position: static;
          }

          .bg-black.bg-opacity-50 {
            display: none;
          }

          .rounded-lg {
            border-radius: 0;
          }

          #voucher-printable-content {
            max-width: 100%;
            padding: 0;
            margin: 0;
            box-shadow: none;
            border-radius: 0;
          }

          @page {
            size: A4;
            margin: 0;
            padding: 0;
          }
        }
      `}</style>
    </div>
  );
};

export { VoucherPreview };
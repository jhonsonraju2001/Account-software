import React, { useState } from 'react';
import { Save, Download, Upload, Trash2 } from 'lucide-react';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { LogoUpload } from '../FileUpload/LogoUpload';

const Settings: React.FC = () => {
  const [invoices, setInvoices] = useLocalStorage('invoices', []);
  const [vouchers, setVouchers] = useLocalStorage('vouchers', []);
  const [balanceSheets, setBalanceSheets] = useLocalStorage('balanceSheets', []);
  
  const [companyDefaults, setCompanyDefaults] = useLocalStorage('companyDefaults', {
    name: '',
    address: '',
    phone: '',
    email: '',
    gstin: '',
    logo: ''
  });

  const exportData = () => {
    const data = {
      invoices,
      vouchers,
      balanceSheets,
      companyDefaults,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `invoice-pro-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        
        if (data.invoices) setInvoices(data.invoices);
        if (data.vouchers) setVouchers(data.vouchers);
        if (data.balanceSheets) setBalanceSheets(data.balanceSheets);
        if (data.companyDefaults) setCompanyDefaults(data.companyDefaults);
        
        alert('Data imported successfully!');
      } catch (error) {
        alert('Error importing data. Please check the file format.');
      }
    };
    reader.readAsText(file);
  };

  const clearAllData = () => {
    if (confirm('Are you sure you want to delete all data? This action cannot be undone.')) {
      setInvoices([]);
      setVouchers([]);
      setBalanceSheets([]);
      setCompanyDefaults({
        name: '',
        address: '',
        phone: '',
        email: '',
        gstin: '',
        logo: ''
      });
      alert('All data cleared successfully!');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Settings</h2>

      {/* Company Defaults */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-700 mb-4">Default Company Information</h3>
        <p className="text-sm text-gray-600 mb-4">Set default company information to auto-fill forms</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
            <input
              type="text"
              value={companyDefaults.name}
              onChange={(e) => setCompanyDefaults({...companyDefaults, name: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="email"
              value={companyDefaults.email}
              onChange={(e) => setCompanyDefaults({...companyDefaults, email: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
            <input
              type="text"
              value={companyDefaults.phone}
              onChange={(e) => setCompanyDefaults({...companyDefaults, phone: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">GSTIN</label>
            <input
              type="text"
              value={companyDefaults.gstin}
              onChange={(e) => setCompanyDefaults({...companyDefaults, gstin: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
            <textarea
              value={companyDefaults.address}
              onChange={(e) => setCompanyDefaults({...companyDefaults, address: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={3}
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Logo URL</label>
            <input
              type="url"
              value={companyDefaults.logo}
              onChange={(e) => setCompanyDefaults({...companyDefaults, logo: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="https://example.com/logo.png"
            />
          </div>
        </div>
      </div>

      {/* Data Management */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-700 mb-4">Data Management</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div>
              <h4 className="font-medium text-gray-800">Export Data</h4>
              <p className="text-sm text-gray-600">Download all your data as a backup file</p>
            </div>
            <button
              onClick={exportData}
              className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition-colors inline-flex items-center"
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </button>
          </div>

          <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div>
              <h4 className="font-medium text-gray-800">Import Data</h4>
              <p className="text-sm text-gray-600">Restore data from a backup file</p>
            </div>
            <div>
              <input
                type="file"
                id="import-file"
                accept=".json"
                onChange={importData}
                className="hidden"
              />
              <label
                htmlFor="import-file"
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center cursor-pointer"
              >
                <Upload className="w-4 h-4 mr-2" />
                Import
              </label>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <LogoUpload
              currentLogo={companyDefaults.logo}
              onLogoChange={(logoUrl) => setCompanyDefaults({...companyDefaults, logo: logoUrl})}
              label="Default Company Logo"
            />
          </div>
          
          <div className="flex justify-end">
            <button
              onClick={() => {
                alert('Company defaults saved successfully!');
              }}
              className="px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Defaults
            </button>
          </div>

          <div className="flex items-center justify-between p-4 border border-red-200 bg-red-50 rounded-lg">
            <div>
              <h4 className="font-medium text-red-800">Clear All Data</h4>
              <p className="text-sm text-red-600">Permanently delete all invoices, vouchers, and settings</p>
            </div>
            <button
              onClick={clearAllData}
              className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors inline-flex items-center"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear All
            </button>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-700 mb-4">Data Statistics</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{invoices.length}</div>
            <div className="text-sm text-gray-600">Total Invoices</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">{vouchers.length}</div>
            <div className="text-sm text-gray-600">Total Vouchers</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">{balanceSheets.length}</div>
            <div className="text-sm text-gray-600">Balance Sheets</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export { Settings };
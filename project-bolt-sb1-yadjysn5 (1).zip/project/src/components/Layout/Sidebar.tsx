import React from 'react';
import {
  FileText,
  Receipt,
  CreditCard,
  BarChart3,
  Settings,
  PlusCircle,
  List,
  LogOut,
  Crown,
  User,
  X
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  user: any;
  onLogout: () => void;
  canAccessPremium: boolean;
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  activeSection, 
  onSectionChange, 
  user, 
  onLogout, 
  canAccessPremium,
  isOpen,
  onClose
}) => {
  const handleSectionChange = (section: string) => {
    onSectionChange(section);
    onClose(); // Close sidebar on mobile after selection
  };

  const menuItems = [
    {
      label: 'Dashboard',
      icon: BarChart3,
      key: 'dashboard'
    },
    {
      label: 'GST Invoices',
      icon: FileText,
      key: 'gst-invoices',
      submenu: [
        { label: 'Create GST Invoice', key: 'create-gst-invoice', icon: PlusCircle },
        { label: 'GST Invoice List', key: 'gst-invoice-list', icon: List }
      ]
    },
    {
      label: 'Normal Bills',
      icon: Receipt,
      key: 'normal-bills',
      submenu: [
        { label: 'Create Normal Bill', key: 'create-normal-bill', icon: PlusCircle },
        { label: 'Normal Bill List', key: 'normal-bill-list', icon: List }
      ]
    },
    {
      label: 'Payment Vouchers',
      icon: CreditCard,
      key: 'payment-vouchers',
      submenu: [
        { label: 'Create Voucher', key: 'create-voucher', icon: PlusCircle },
        { label: 'Voucher List', key: 'voucher-list', icon: List }
      ]
    },
    {
      label: 'Car Rental Bills',
      icon: Receipt,
      key: 'car-rental',
      submenu: [
        { label: 'Create Car Rental', key: 'create-car-rental', icon: PlusCircle },
        { label: 'Car Rental List', key: 'car-rental-list', icon: List }
      ]
    },
    {
      label: 'Balance Sheet',
      icon: BarChart3,
      key: 'balance-sheet'
    },
    {
      label: 'Settings',
      icon: Settings,
      key: 'settings'
    }
  ];

  return (
    <div className={`w-64 bg-white shadow-lg h-screen fixed left-0 top-0 z-50 flex flex-col transform transition-transform duration-300 ease-in-out ${
      isOpen ? 'translate-x-0' : '-translate-x-full'
    } lg:translate-x-0`}>
      {/* Logout Button - Top Left */}
      
      {/* Fixed Header */}
      <div className="p-6 border-b flex-shrink-0">
        <div className="flex items-center justify-between lg:justify-start">
        <h1 className="text-xl font-bold text-gray-800">Invoice Pro</h1>
          <button
            onClick={onClose}
            className="lg:hidden p-2 hover:bg-gray-100 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <p className="text-sm text-gray-600">Billing Management</p>
        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center">
            <User className="w-4 h-4 text-gray-500 mr-2" />
            <span className="text-sm text-gray-700">{user.name}</span>
          </div>
          {user.subscriptionStatus === 'premium' && (
            <div className="flex items-center">
              <Crown className="w-4 h-4 text-yellow-500 mr-1" />
              <span className="text-xs text-yellow-600">Premium</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Fixed Dashboard */}
      <div className="flex-shrink-0 border-b">
        <button
          onClick={() => handleSectionChange('dashboard')}
          className={`w-full flex items-center px-6 py-3 text-left hover:bg-blue-50 transition-colors ${
            activeSection === 'dashboard' ? 'bg-blue-100 border-r-2 border-blue-500' : ''
          }`}
        >
          <BarChart3 className="w-5 h-5 mr-3 text-gray-600" />
          <span className="text-gray-700 font-medium">Dashboard</span>
        </button>
      </div>
      
      {/* Scrollable Menu Items */}
      <nav className="flex-1 overflow-y-auto">
        {menuItems.map((item) => (
          <div key={item.key}>
            <button
              onClick={() => handleSectionChange(item.key)}
              className={`w-full flex items-center px-6 py-3 text-left hover:bg-blue-50 transition-colors ${
                activeSection === item.key ? 'bg-blue-100 border-r-2 border-blue-500' : ''
              }`}
            >
              <item.icon className="w-5 h-5 mr-3 text-gray-600" />
              <span className="text-gray-700 font-medium">{item.label}</span>
            </button>
            
            {item.submenu && (
              <div className="ml-4 border-l-2 border-gray-100">
                {item.submenu.map((subItem) => (
                  <button
                    key={subItem.key}
                    onClick={() => handleSectionChange(subItem.key)}
                    className={`w-full flex items-center px-6 py-2 text-left hover:bg-gray-50 transition-colors ${
                      activeSection === subItem.key ? 'bg-gray-100 text-blue-600' : ''
                    }`}
                    disabled={subItem.key.includes('export') && !canAccessPremium}
                  >
                    <subItem.icon className="w-4 h-4 mr-3 text-gray-500" />
                    <span className={`text-sm ${subItem.key.includes('export') && !canAccessPremium ? 'text-gray-400' : 'text-gray-600'}`}>
                      {subItem.label}
                      {subItem.key.includes('export') && !canAccessPremium && (
                        <Crown className="w-3 h-3 inline ml-1 text-yellow-500" />
                      )}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </div>
  );
};

export { Sidebar };
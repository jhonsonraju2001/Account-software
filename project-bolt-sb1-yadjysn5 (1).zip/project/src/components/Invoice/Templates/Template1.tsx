import React from 'react';
import { Invoice } from '../../../types/invoice';
import { formatDate } from '../../../utils/dateUtils';

interface Template1Props {
  invoice: Invoice;
}

const Template1: React.FC<Template1Props> = ({ invoice }) => {
  return (
    <div className="bg-white p-8 max-w-4xl mx-auto print:p-0">
      {/* Header */}
      <div className="flex justify-between items-start mb-8 pb-6 border-b-2 border-blue-500">
        <div className="flex items-center">
          {invoice.company.logo && (
            <img 
              src={invoice.company.logo} 
              alt="Company Logo" 
              className="w-16 h-16 mr-4 object-contain"
            />
          )}
          <div>
            <h1 className="text-3xl font-bold text-blue-600">{invoice.company.name}</h1>
            <p className="text-gray-600 mt-1">Professional Invoice</p>
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            {invoice.type === 'gst' ? 'GST INVOICE' : 
             invoice.type === 'proforma' ? 'PROFORMA INVOICE' : 'BILL'}
          </h2>
          <p className="text-lg font-semibold text-blue-600">{invoice.invoiceNumber}</p>
          <div className="mt-4 text-sm text-gray-600">
            <p><strong>Date:</strong> {formatDate(invoice.date)}</p>
            <p><strong>Due Date:</strong> {formatDate(invoice.dueDate)}</p>
            <p><strong>Days Until Due:</strong> {invoice.daysUntilDue} days</p>
          </div>
        </div>
      </div>

      {/* Company and Client Info */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3 bg-blue-50 p-2 rounded">From:</h3>
          <div className="space-y-1 text-gray-700">
            <p className="font-semibold">{invoice.company.name}</p>
            <p>{invoice.company.address}</p>
            <p>Phone: {invoice.company.phone}</p>
            <p>Email: {invoice.company.email}</p>
            {invoice.company.gstin && <p>GSTIN: {invoice.company.gstin}</p>}
          </div>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3 bg-green-50 p-2 rounded">To:</h3>
          <div className="space-y-1 text-gray-700">
            <p className="font-semibold">{invoice.client.name}</p>
            <p>{invoice.client.address}</p>
            <p>Phone: {invoice.client.phone}</p>
            <p>Email: {invoice.client.email}</p>
            {invoice.client.gstin && <p>GSTIN: {invoice.client.gstin}</p>}
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="mb-8">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="border border-gray-300 p-3 text-left">Description</th>
              <th className="border border-gray-300 p-3 text-center w-16">Qty</th>
              <th className="border border-gray-300 p-3 text-center w-24">Rate</th>
              {invoice.type === 'gst' && <th className="border border-gray-300 p-3 text-center w-16">GST%</th>}
              {invoice.type === 'gst' && <th className="border border-gray-300 p-3 text-center w-24">GST Amount</th>}
              <th className="border border-gray-300 p-3 text-center w-24">Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item) => (
              <tr key={item.id} className="hover:bg-gray-50">
                <td className="border border-gray-300 p-3">{item.description}</td>
                <td className="border border-gray-300 p-3 text-center">{item.quantity}</td>
                <td className="border border-gray-300 p-3 text-center">₹{item.rate.toFixed(2)}</td>
                {invoice.type === 'gst' && <td className="border border-gray-300 p-3 text-center">{item.gstRate}%</td>}
                {invoice.type === 'gst' && <td className="border border-gray-300 p-3 text-center">₹{item.gstAmount?.toFixed(2)}</td>}
                <td className="border border-gray-300 p-3 text-center font-semibold">₹{item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div className="flex justify-end mb-8">
        <div className="w-80">
          <div className="bg-gray-50 p-4 rounded-lg space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>₹{invoice.subtotal.toFixed(2)}</span>
            </div>
            {invoice.type === 'gst' && invoice.gstTotal && (
              <div className="flex justify-between">
                <span>GST Total:</span>
                <span>₹{invoice.gstTotal.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-lg font-bold border-t pt-2">
              <span>Total Amount:</span>
              <span className="text-blue-600">₹{invoice.total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Info */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Payment Details</h3>
          <div className="space-y-2 text-gray-700">
            <p><strong>Payment Mode:</strong> {invoice.paymentMode}</p>
            <p><strong>Status:</strong> 
              <span className={`ml-2 px-2 py-1 rounded text-xs ${
                invoice.paymentStatus === 'paid' 
                  ? 'bg-green-100 text-green-800' 
                  : invoice.paymentStatus === 'partially_paid'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {invoice.paymentStatus.replace('_', ' ').toUpperCase()}
              </span>
            </p>
          </div>
        </div>
        {invoice.notes && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Notes</h3>
            <p className="text-gray-700">{invoice.notes}</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t pt-4 text-center text-gray-600">
        <p className="text-sm">Thank you for your business!</p>
        <p className="text-xs mt-2">This is a computer-generated invoice.</p>
      </div>
    </div>
  );
};

export { Template1 };
import React from 'react';
import { Invoice } from '../../../types/invoice';
import { formatDate } from '../../../utils/dateUtils';

interface Template3Props {
  invoice: Invoice;
}

const Template3: React.FC<Template3Props> = ({ invoice }) => {
  return (
    <div className="bg-white p-8 max-w-4xl mx-auto print:p-0">
      {/* Header */}
      <div className="flex justify-between items-center mb-12">
        <div className="flex items-center">
          {invoice.company.logo && (
            <img 
              src={invoice.company.logo} 
              alt="Company Logo" 
              className="w-20 h-20 mr-6 object-contain"
            />
          )}
          <div>
            <h1 className="text-4xl font-light text-gray-800">{invoice.company.name}</h1>
            <p className="text-gray-500 text-lg mt-1">Minimal Design</p>
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-3xl font-light text-gray-700 mb-2">
            {invoice.type === 'gst' ? 'GST INVOICE' : 
             invoice.type === 'proforma' ? 'PROFORMA INVOICE' : 'BILL'}
          </h2>
          <p className="text-xl text-gray-600">{invoice.invoiceNumber}</p>
        </div>
      </div>

      {/* Date and Due Information */}
      <div className="grid grid-cols-4 gap-8 mb-12 border-t border-b border-gray-200 py-6">
        <div>
          <p className="text-sm text-gray-500 uppercase tracking-wider">Invoice Date</p>
          <p className="text-lg font-medium">{formatDate(invoice.date)}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500 uppercase tracking-wider">Due Date</p>
          <p className="text-lg font-medium">{formatDate(invoice.dueDate)}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500 uppercase tracking-wider">Days Until Due</p>
          <p className="text-lg font-medium">{invoice.daysUntilDue} days</p>
        </div>
        <div>
          <p className="text-sm text-gray-500 uppercase tracking-wider">Payment Mode</p>
          <p className="text-lg font-medium">{invoice.paymentMode}</p>
        </div>
      </div>

      {/* Company and Client Info */}
      <div className="grid grid-cols-2 gap-12 mb-12">
        <div>
          <h3 className="text-lg font-medium text-gray-700 mb-4 uppercase tracking-wider">From</h3>
          <div className="space-y-2 text-gray-600">
            <p className="text-lg font-medium text-gray-800">{invoice.company.name}</p>
            <p>{invoice.company.address}</p>
            <p>{invoice.company.phone} • {invoice.company.email}</p>
            {invoice.company.gstin && <p>GSTIN: {invoice.company.gstin}</p>}
          </div>
        </div>
        <div>
          <h3 className="text-lg font-medium text-gray-700 mb-4 uppercase tracking-wider">To</h3>
          <div className="space-y-2 text-gray-600">
            <p className="text-lg font-medium text-gray-800">{invoice.client.name}</p>
            <p>{invoice.client.address}</p>
            <p>{invoice.client.phone} • {invoice.client.email}</p>
            {invoice.client.gstin && <p>GSTIN: {invoice.client.gstin}</p>}
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="mb-12">
        <table className="w-full">
          <thead>
            <tr className="border-b-2 border-gray-300">
              <th className="py-4 text-left text-sm font-medium text-gray-700 uppercase tracking-wider">Description</th>
              <th className="py-4 text-center text-sm font-medium text-gray-700 uppercase tracking-wider w-16">Qty</th>
              <th className="py-4 text-center text-sm font-medium text-gray-700 uppercase tracking-wider w-24">Rate</th>
              {invoice.type === 'gst' && <th className="py-4 text-center text-sm font-medium text-gray-700 uppercase tracking-wider w-16">GST%</th>}
              {invoice.type === 'gst' && <th className="py-4 text-center text-sm font-medium text-gray-700 uppercase tracking-wider w-24">GST</th>}
              <th className="py-4 text-right text-sm font-medium text-gray-700 uppercase tracking-wider w-24">Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item) => (
              <tr key={item.id} className="border-b border-gray-100">
                <td className="py-4 text-gray-800">{item.description}</td>
                <td className="py-4 text-center text-gray-600">{item.quantity}</td>
                <td className="py-4 text-center text-gray-600">₹{item.rate.toFixed(2)}</td>
                {invoice.type === 'gst' && <td className="py-4 text-center text-gray-600">{item.gstRate}%</td>}
                {invoice.type === 'gst' && <td className="py-4 text-center text-gray-600">₹{item.gstAmount?.toFixed(2)}</td>}
                <td className="py-4 text-right font-medium">₹{item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div className="flex justify-end mb-12">
        <div className="w-80">
          <div className="space-y-3">
            <div className="flex justify-between pb-2">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium">₹{invoice.subtotal.toFixed(2)}</span>
            </div>
            {invoice.type === 'gst' && invoice.gstTotal && (
              <div className="flex justify-between pb-2">
                <span className="text-gray-600">GST Total</span>
                <span className="font-medium">₹{invoice.gstTotal.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-2xl font-light border-t-2 border-gray-300 pt-4">
              <span className="text-gray-800">Total</span>
              <span className="text-gray-800">₹{invoice.total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Status and Notes */}
      <div className="grid grid-cols-2 gap-12 mb-12">
        <div>
          <h3 className="text-lg font-medium text-gray-700 mb-4 uppercase tracking-wider">Payment Status</h3>
          <span className={`px-4 py-2 rounded text-sm font-medium ${
            invoice.paymentStatus === 'paid' 
              ? 'bg-green-100 text-green-800' 
              : invoice.paymentStatus === 'partially_paid'
              ? 'bg-yellow-100 text-yellow-800'
              : 'bg-red-100 text-red-800'
          }`}>
            {invoice.paymentStatus.replace('_', ' ').toUpperCase()}
          </span>
        </div>
        {invoice.notes && (
          <div>
            <h3 className="text-lg font-medium text-gray-700 mb-4 uppercase tracking-wider">Notes</h3>
            <p className="text-gray-600 leading-relaxed">{invoice.notes}</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="text-center border-t border-gray-200 pt-8">
        <p className="text-lg font-light text-gray-700">Thank you for your business</p>
        <p className="text-sm text-gray-500 mt-2">Minimal Invoice Template</p>
      </div>
    </div>
  );
};

export { Template3 };
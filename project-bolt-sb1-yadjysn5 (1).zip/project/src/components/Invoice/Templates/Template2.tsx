import React from 'react';
import { Invoice } from '../../../types/invoice';
import { formatDate } from '../../../utils/dateUtils';

interface Template2Props {
  invoice: Invoice;
}

const Template2: React.FC<Template2Props> = ({ invoice }) => {
  return (
    <div className="bg-white p-8 max-w-4xl mx-auto print:p-0 border-2 border-gray-800">
      {/* Header */}
      <div className="bg-gray-800 text-white p-6 -m-8 mb-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {invoice.company.logo && (
              <img 
                src={invoice.company.logo} 
                alt="Company Logo" 
                className="w-12 h-12 mr-4 object-contain bg-white rounded p-1"
              />
            )}
            <div>
              <h1 className="text-2xl font-bold">{invoice.company.name}</h1>
              <p className="text-gray-300">Classic Business Invoice</p>
            </div>
          </div>
          <div className="text-right">
            <h2 className="text-xl font-bold mb-2">
              {invoice.type === 'gst' ? 'GST INVOICE' : 
               invoice.type === 'proforma' ? 'PROFORMA INVOICE' : 'BILL'}
            </h2>
            <p className="text-lg">{invoice.invoiceNumber}</p>
          </div>
        </div>
      </div>

      {/* Invoice Details */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        <div>
          <h3 className="font-semibold text-gray-800 mb-2 border-b border-gray-300 pb-1">Invoice Details</h3>
          <div className="text-sm space-y-1">
            <p><strong>Date:</strong> {formatDate(invoice.date)}</p>
            <p><strong>Due Date:</strong> {formatDate(invoice.dueDate)}</p>
            <p><strong>Days Until Due:</strong> {invoice.daysUntilDue} days</p>
          </div>
        </div>
        <div>
          <h3 className="font-semibold text-gray-800 mb-2 border-b border-gray-300 pb-1">From</h3>
          <div className="text-sm space-y-1">
            <p className="font-semibold">{invoice.company.name}</p>
            <p>{invoice.company.address}</p>
            <p>{invoice.company.phone}</p>
            <p>{invoice.company.email}</p>
            {invoice.company.gstin && <p>GSTIN: {invoice.company.gstin}</p>}
          </div>
        </div>
        <div>
          <h3 className="font-semibold text-gray-800 mb-2 border-b border-gray-300 pb-1">To</h3>
          <div className="text-sm space-y-1">
            <p className="font-semibold">{invoice.client.name}</p>
            <p>{invoice.client.address}</p>
            <p>{invoice.client.phone}</p>
            <p>{invoice.client.email}</p>
            {invoice.client.gstin && <p>GSTIN: {invoice.client.gstin}</p>}
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="mb-8">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-800 text-white">
              <th className="p-3 text-left">Description</th>
              <th className="p-3 text-center w-16">Qty</th>
              <th className="p-3 text-center w-24">Rate</th>
              {invoice.type === 'gst' && <th className="p-3 text-center w-16">GST%</th>}
              {invoice.type === 'gst' && <th className="p-3 text-center w-24">GST</th>}
              <th className="p-3 text-center w-24">Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item, index) => (
              <tr key={item.id} className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}`}>
                <td className="p-3">{item.description}</td>
                <td className="p-3 text-center">{item.quantity}</td>
                <td className="p-3 text-center">₹{item.rate.toFixed(2)}</td>
                {invoice.type === 'gst' && <td className="p-3 text-center">{item.gstRate}%</td>}
                {invoice.type === 'gst' && <td className="p-3 text-center">₹{item.gstAmount?.toFixed(2)}</td>}
                <td className="p-3 text-center font-semibold">₹{item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div className="flex justify-end mb-8">
        <div className="w-80">
          <div className="border-2 border-gray-800 p-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>₹{invoice.subtotal.toFixed(2)}</span>
              </div>
              {invoice.type === 'gst' && invoice.gstTotal && (
                <div className="flex justify-between">
                  <span>GST Total:</span>
                  <span>₹{invoice.gstTotal.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold bg-gray-800 text-white p-2 -m-4 mt-2">
                <span>Total Amount:</span>
                <span>₹{invoice.total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment and Notes */}
      <div className="grid grid-cols-2 gap-8 mb-8 border-t-2 border-gray-800 pt-6">
        <div>
          <h3 className="font-semibold text-gray-800 mb-3">Payment Information</h3>
          <div className="space-y-2 text-sm">
            <p><strong>Payment Mode:</strong> {invoice.paymentMode}</p>
            <p><strong>Status:</strong> 
              <span className={`ml-2 px-2 py-1 rounded text-xs ${
                invoice.paymentStatus === 'paid' 
                  ? 'bg-green-100 text-green-800' 
                  : invoice.paymentStatus === 'partially_paid'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {invoice.paymentStatus.replace('_', ' ').toUpperCase()}
              </span>
            </p>
          </div>
        </div>
        {invoice.notes && (
          <div>
            <h3 className="font-semibold text-gray-800 mb-3">Additional Notes</h3>
            <p className="text-sm">{invoice.notes}</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-gray-100 p-4 -m-8 mt-8 text-center">
        <p className="font-semibold">Thank you for choosing {invoice.company.name}!</p>
        <p className="text-sm text-gray-600 mt-1">Classic Invoice Template</p>
      </div>
    </div>
  );
};

export { Template2 };
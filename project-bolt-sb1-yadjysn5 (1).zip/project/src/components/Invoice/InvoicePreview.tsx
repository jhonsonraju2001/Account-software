import React, { useState } from 'react';
import { X, Printer, FileText, Edit2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { Invoice } from '../../types/invoice';
import { formatDate } from '../../utils/dateUtils';
import { Template1 } from './Templates/Template1';
import { Template2 } from './Templates/Template2';
import { Template3 } from './Templates/Template3';

interface InvoicePreviewProps {
  invoice: Invoice;
  onClose: () => void;
  onEdit?: () => void;
}

const InvoicePreview: React.FC<InvoicePreviewProps> = ({ invoice, onClose, onEdit }) => {
  const [isDownloading, setIsDownloading] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    setIsDownloading(true);
    try {
      const element = document.getElementById('invoice-printable-content');
      if (!element) {
        alert('Error: Document not found');
        setIsDownloading(false);
        return;
      }

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgData = canvas.toDataURL('image/png');
      const pageWidth = 210;
      const pageHeight = 297;
      const imgWidth = 200;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`invoice-${invoice.invoiceNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const renderTemplate = () => {
    switch (invoice.template) {
      case 2:
        return <Template2 invoice={invoice} />;
      case 3:
        return <Template3 invoice={invoice} />;
      default:
        return <Template1 invoice={invoice} />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center print:hidden">
          <h2 className="text-xl font-bold text-gray-800">Invoice Preview</h2>
          <div className="flex space-x-2">
            {onEdit && (
              <button
                onClick={onEdit}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center text-sm"
              >
                <Edit2 className="w-4 h-4 mr-2" />
                Edit
              </button>
            )}
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors inline-flex items-center text-sm"
            >
              <Printer className="w-4 h-4 mr-2" />
              Print
            </button>
            <button
              onClick={handleDownloadPDF}
              disabled={isDownloading}
              className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:bg-gray-400 transition-colors inline-flex items-center text-sm"
            >
              <FileText className="w-4 h-4 mr-2" />
              {isDownloading ? 'Generating...' : 'PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div id="invoice-printable-content" className="p-6 bg-white">
          {renderTemplate()}
        </div>
      </div>

      <style>{`
        @media print {
          * {
            -webkit-print-color-adjust: exact !important;
            color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          body {
            margin: 0;
            padding: 0;
          }

          .fixed {
            position: static;
          }

          .bg-black.bg-opacity-50 {
            display: none;
          }

          .rounded-lg {
            border-radius: 0;
          }

          #invoice-printable-content {
            max-width: 100%;
            padding: 0;
            margin: 0;
            box-shadow: none;
            border-radius: 0;
          }

          @page {
            size: A4;
            margin: 0;
            padding: 0;
          }
        }
      `}</style>
    </div>
  );
};

export { InvoicePreview };

import React, { useState } from 'react';
import { Save, Eye, ArrowLeft } from 'lucide-react';
import { PaymentVoucher, Company, Client } from '../../types/invoice';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { generateVoucherNumber } from '../../utils/dateUtils';
import { LogoUpload } from '../FileUpload/LogoUpload';
import { VoucherPreview } from '../Voucher/VoucherPreview';

interface VoucherFormProps {
  onSubmit: (voucher: PaymentVoucher) => void;
  onBack?: () => void;
}

const VoucherForm: React.FC<VoucherFormProps> = ({ onSubmit, onBack }) => {
  const [vouchers, setVouchers] = useLocalStorage<PaymentVoucher[]>('vouchers', []);
  const [companyDefaults] = useLocalStorage('companyDefaults', {
    name: '',
    address: '',
    phone: '',
    email: '',
    logo: ''
  });
  const [showPreview, setShowPreview] = useState(false);
  
  const [voucherType, setVoucherType] = useState<'payment' | 'advance' | 'receipt'>('payment');
  
  const [company, setCompany] = useState<Company>(companyDefaults);

  const [client, setClient] = useState<Client>({
    name: '',
    address: '',
    phone: '',
    email: ''
  });

  const [voucherData, setVoucherData] = useState({
    date: new Date().toISOString().split('T')[0],
    amount: 0,
    totalAmount: 0,
    advancePayment: 0,
    remainingBalance: 0,
    paymentMode: 'Cash',
    reference: '',
    description: '',
    template: 1
  });

  // Calculate remaining balance automatically
  const calculateRemainingBalance = () => {
    const remaining = voucherData.totalAmount - voucherData.advancePayment;
    setVoucherData(prev => ({
      ...prev,
      remainingBalance: remaining > 0 ? remaining : 0
    }));
  };

  // Update calculations when total amount or advance payment changes
  React.useEffect(() => {
    calculateRemainingBalance();
  }, [voucherData.totalAmount, voucherData.advancePayment]);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const voucher: PaymentVoucher = {
      id: Date.now().toString(),
      type: voucherType,
      voucherNumber: generateVoucherNumber(voucherType, vouchers.length),
      date: voucherData.date,
      company,
      client,
      amount: voucherData.amount,
      totalAmount: voucherData.totalAmount,
      advancePayment: voucherData.advancePayment,
      remainingBalance: voucherData.remainingBalance,
      paymentMode: voucherData.paymentMode,
      reference: voucherData.reference,
      description: voucherData.description,
      status: 'paid',
      template: voucherData.template,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setVouchers([...vouchers, voucher]);
    onClose();
  };

  const currentVoucher: PaymentVoucher = {
    id: 'preview',
    type: voucherType,
    voucherNumber: generateVoucherNumber(voucherType, vouchers.length),
    date: voucherData.date,
    company,
    client,
    amount: voucherData.amount,
    totalAmount: voucherData.totalAmount,
    advancePayment: voucherData.advancePayment,
    remainingBalance: voucherData.remainingBalance,
    paymentMode: voucherData.paymentMode,
    reference: voucherData.reference,
    description: voucherData.description,
    status: 'paid',
    template: voucherData.template,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  if (showPreview) {
    return (
      <VoucherPreview
        voucher={currentVoucher}
        onClose={() => setShowPreview(false)}
        onEdit={() => setShowPreview(false)}
      />
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 lg:p-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          {onBack && (
            <button
              onClick={onBack}
              type="button"
              className="mr-4 p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-lg lg:text-2xl font-bold text-gray-800">Create Payment Voucher</h2>
        </div>
        <button
          onClick={() => setShowPreview(true)}
          type="button"
          className="px-2 lg:px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors inline-flex items-center text-sm"
        >
          <Eye className="w-4 h-4 mr-2" />
          <span className="hidden sm:inline">Preview</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Voucher Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Voucher Type</label>
          <div className="grid grid-cols-3 gap-4">
            {[
              { value: 'payment', label: 'Payment Voucher' },
              { value: 'advance', label: 'Advance Payment' },
              { value: 'receipt', label: 'Payment Receipt' }
            ].map((option) => (
              <label key={option.value} className="flex items-center">
                <input
                  type="radio"
                  name="voucherType"
                  value={option.value}
                  checked={voucherType === option.value}
                  onChange={(e) => setVoucherType(e.target.value as 'payment' | 'advance' | 'receipt')}
                  className="mr-2"
                />
                <span>{option.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Company and Client Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Company Information</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
              <input
                type="text"
                required
                value={company.name}
                onChange={(e) => setCompany({...company, name: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea
                required
                value={company.address}
                onChange={(e) => setCompany({...company, address: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="text"
                  required
                  value={company.phone}
                  onChange={(e) => setCompany({...company, phone: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={company.email}
                  onChange={(e) => setCompany({...company, email: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <LogoUpload
                currentLogo={company.logo}
                onLogoChange={(logoUrl) => setCompany({...company, logo: logoUrl})}
                label="Company Logo (Optional)"
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">
              {voucherType === 'payment' ? 'Payee' : 'Client'} Information
            </h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
              <input
                type="text"
                required
                value={client.name}
                onChange={(e) => setClient({...client, name: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea
                required
                value={client.address}
                onChange={(e) => setClient({...client, address: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="text"
                  required
                  value={client.phone}
                  onChange={(e) => setClient({...client, phone: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={client.email}
                  onChange={(e) => setClient({...client, email: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Voucher Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Payment Breakdown</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Total Amount</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={voucherData.totalAmount}
                onChange={(e) => setVoucherData({...voucherData, totalAmount: parseFloat(e.target.value) || 0})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Total invoice/bill amount"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Advance Payment</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={voucherData.advancePayment}
                onChange={(e) => setVoucherData({...voucherData, advancePayment: parseFloat(e.target.value) || 0})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Amount paid in advance"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Remaining Balance</label>
              <input
                type="number"
                value={voucherData.remainingBalance}
                readOnly
                className="w-full p-2 border border-gray-300 rounded bg-gray-100 text-gray-600"
                placeholder="Auto-calculated"
              />
              <p className="text-xs text-gray-500 mt-1">Automatically calculated: Total Amount - Advance Payment</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Voucher Details</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
            <input
              type="date"
              required
              value={voucherData.date}
              onChange={(e) => setVoucherData({...voucherData, date: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Current Payment Amount</label>
            <input
              type="number"
              min="0"
              step="0.01"
              required
              value={voucherData.amount}
              onChange={(e) => setVoucherData({...voucherData, amount: parseFloat(e.target.value)})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Amount being paid now"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Payment Mode</label>
            <select
              value={voucherData.paymentMode}
              onChange={(e) => setVoucherData({...voucherData, paymentMode: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="Cash">Cash</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cheque">Cheque</option>
              <option value="UPI">UPI</option>
              <option value="Card">Card</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Template</label>
            <select
              value={voucherData.template}
              onChange={(e) => setVoucherData({...voucherData, template: parseInt(e.target.value)})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={1}>Template 1 - Modern</option>
              <option value={2}>Template 2 - Classic</option>
              <option value={3}>Template 3 - Minimal</option>
            </select>
          </div>
        </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Reference/Cheque No.</label>
          <input
            type="text"
            value={voucherData.reference}
            onChange={(e) => setVoucherData({...voucherData, reference: e.target.value})}
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Reference number, cheque number, etc."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea
            required
            value={voucherData.description}
            onChange={(e) => setVoucherData({...voucherData, description: e.target.value})}
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={3}
            placeholder="Payment description or purpose"
          />
        </div>

        <div className="flex justify-end space-x-4">
          <button
            type="submit"
            className="px-6 py-2 bg-[#3f7a12] text-white rounded hover:bg-[#2d5a0c] transition-colors inline-flex items-center"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Voucher
          </button>
        </div>
      </form>
    </div>
  );
};

export { VoucherForm };
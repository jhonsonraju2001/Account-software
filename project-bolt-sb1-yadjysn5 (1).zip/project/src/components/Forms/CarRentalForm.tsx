import React, { useState } from 'react';
import { Save, Eye, Car, ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { CarRentalBill, RentalDay } from '../../types/carRental';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { LogoUpload } from '../FileUpload/LogoUpload';
import { CarRentalPreview } from '../CarRental/CarRentalPreview';

interface CarRentalFormProps {
  onSubmit: (bill: CarRentalBill) => void;
  onBack?: () => void;
}

const CarRentalForm: React.FC<CarRentalFormProps> = ({ onSubmit, onBack }) => {
  const [carRentalBills, setCarRentalBills] = useLocalStorage<CarRentalBill[]>('carRentalBills', []);
  const [companyDefaults] = useLocalStorage('companyDefaults', {
    name: '',
    address: '',
    phone: '',
    email: '',
    logo: ''
  });
  const [showPreview, setShowPreview] = useState(false);

  const [company, setCompany] = useState(companyDefaults);
  const [client, setClient] = useState({
    name: '',
    address: '',
    phone: '',
    email: ''
  });

  const [billData, setBillData] = useState({
    date: new Date().toISOString().split('T')[0],
    paymentMode: 'Cash',
    bookedBy: '',
    remarks: ''
  });

  const [rentalDays, setRentalDays] = useState<RentalDay[]>([
    {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      driverName: '',
      carNumber: '',
      reportingPlace: '',
      startingKm: 0,
      closingKm: 0,
      totalKm: 0,
      startingTime: '',
      closingTime: '',
      totalHours: 0,
      dailyRate: 0,
      extraKmRate: 0,
      extraHourRate: 0,
      extraKm: 0,
      extraHours: 0,
      extraKmCharges: 0,
      extraHourCharges: 0,
      dayTotal: 0
    }
  ]);

  const generateBillNumber = () => {
    return `CR-${new Date().getFullYear()}-${String(carRentalBills.length + 1).padStart(4, '0')}`;
  };

  const updateRentalDay = (index: number, field: keyof RentalDay, value: any) => {
    const updatedDays = [...rentalDays];
    updatedDays[index] = { ...updatedDays[index], [field]: value };

    // Auto-calculate totalKm
    if (field === 'startingKm' || field === 'closingKm') {
      updatedDays[index].totalKm = Math.max(0, updatedDays[index].closingKm - updatedDays[index].startingKm);
    }

    // Auto-calculate totalHours
    if (field === 'startingTime' || field === 'closingTime') {
      if (updatedDays[index].startingTime && updatedDays[index].closingTime) {
        const start = new Date(`2000-01-01 ${updatedDays[index].startingTime}`);
        const end = new Date(`2000-01-01 ${updatedDays[index].closingTime}`);
        let diff = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
        if (diff < 0) diff += 24;
        updatedDays[index].totalHours = Math.round(diff * 100) / 100;
      }
    }

    // Calculate day total
    let dayTotal = updatedDays[index].dailyRate || 0;
    updatedDays[index].extraKm = Math.max(0, updatedDays[index].totalKm - 80);
    updatedDays[index].extraHours = Math.max(0, updatedDays[index].totalHours - 8);
    updatedDays[index].extraKmCharges = updatedDays[index].extraKm * updatedDays[index].extraKmRate;
    updatedDays[index].extraHourCharges = updatedDays[index].extraHours * updatedDays[index].extraHourRate;
    dayTotal += updatedDays[index].extraKmCharges + updatedDays[index].extraHourCharges;
    updatedDays[index].dayTotal = dayTotal;

    setRentalDays(updatedDays);
  };

  const addDay = () => {
    const lastDay = rentalDays[rentalDays.length - 1];
    const nextDate = new Date(lastDay.date);
    nextDate.setDate(nextDate.getDate() + 1);

    const newDay: RentalDay = {
      id: Date.now().toString(),
      date: nextDate.toISOString().split('T')[0],
      driverName: lastDay.driverName,
      carNumber: lastDay.carNumber,
      reportingPlace: lastDay.reportingPlace,
      startingKm: lastDay.closingKm,
      closingKm: 0,
      totalKm: 0,
      startingTime: '',
      closingTime: '',
      totalHours: 0,
      dailyRate: lastDay.dailyRate,
      extraKmRate: lastDay.extraKmRate,
      extraHourRate: lastDay.extraHourRate,
      extraKm: 0,
      extraHours: 0,
      extraKmCharges: 0,
      extraHourCharges: 0,
      dayTotal: 0
    };

    setRentalDays([...rentalDays, newDay]);
  };

  const removeDay = (index: number) => {
    if (rentalDays.length > 1) {
      setRentalDays(rentalDays.filter((_, i) => i !== index));
    }
  };

  const calculateTotals = () => {
    const subtotal = rentalDays.reduce((sum, day) => sum + day.dayTotal, 0);
    return { subtotal };
  };

  const totals = calculateTotals();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const bill: CarRentalBill = {
      id: Date.now().toString(),
      billNumber: generateBillNumber(),
      date: billData.date,
      company,
      client,
      bookedBy: billData.bookedBy,
      remarks: billData.remarks,
      rentalDays,
      charges: {
        subtotal: totals.subtotal,
        extraCharges: 0,
        totalAmount: totals.subtotal
      },
      paymentMode: billData.paymentMode,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSubmit(bill);
  };

  const currentBill: CarRentalBill = {
    id: 'preview',
    billNumber: generateBillNumber(),
    date: billData.date,
    company,
    client,
    bookedBy: billData.bookedBy,
    remarks: billData.remarks,
    rentalDays,
    charges: {
      subtotal: totals.subtotal,
      extraCharges: 0,
      totalAmount: totals.subtotal
    },
    paymentMode: billData.paymentMode,
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  if (showPreview) {
    return (
      <CarRentalPreview
        bill={currentBill}
        onClose={() => setShowPreview(false)}
        onEdit={() => setShowPreview(false)}
      />
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 lg:p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          {onBack && (
            <button
              onClick={onBack}
              type="button"
              className="mr-4 p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-lg lg:text-2xl font-bold text-gray-800 flex items-center">
            <Car className="w-6 h-6 mr-2 text-[#3f7a12]" />
            <span className="hidden sm:inline">Create Car Rental Bill</span>
            <span className="sm:hidden">Car Rental</span>
          </h2>
        </div>
        <button
          onClick={() => setShowPreview(true)}
          type="button"
          className="px-3 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors inline-flex items-center text-sm"
        >
          <Eye className="w-4 h-4 mr-1" />
          <span className="hidden sm:inline">Preview</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Company and Client Information */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Company Information</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
              <input
                type="text"
                required
                value={company.name}
                onChange={(e) => setCompany({...company, name: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea
                required
                value={company.address}
                onChange={(e) => setCompany({...company, address: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="text"
                  required
                  value={company.phone}
                  onChange={(e) => setCompany({...company, phone: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={company.email}
                  onChange={(e) => setCompany({...company, email: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <LogoUpload
              currentLogo={company.logo}
              onLogoChange={(logoUrl) => setCompany({...company, logo: logoUrl})}
              label="Company Logo (Optional)"
            />
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Client & Bill Information</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Client Name</label>
              <input
                type="text"
                required
                value={client.name}
                onChange={(e) => setClient({...client, name: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea
                required
                value={client.address}
                onChange={(e) => setClient({...client, address: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="text"
                  required
                  value={client.phone}
                  onChange={(e) => setClient({...client, phone: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={client.email}
                  onChange={(e) => setClient({...client, email: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={billData.date}
                  onChange={(e) => setBillData({...billData, date: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Payment Mode</label>
                <select
                  value={billData.paymentMode}
                  onChange={(e) => setBillData({...billData, paymentMode: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Cash">Cash</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Cheque">Cheque</option>
                  <option value="UPI">UPI</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Booked By & Remarks */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Booked By</label>
            <input
              type="text"
              required
              value={billData.bookedBy}
              onChange={(e) => setBillData({...billData, bookedBy: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Remarks</label>
            <input
              type="text"
              value={billData.remarks}
              onChange={(e) => setBillData({...billData, remarks: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Rental Days */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-700">Rental Days ({rentalDays.length})</h3>
            <button
              type="button"
              onClick={addDay}
              className="px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center text-sm"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add Day
            </button>
          </div>

          {rentalDays.map((day, index) => (
            <div key={day.id} className="border-2 border-gray-200 rounded-lg p-4 bg-gray-50">
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-semibold text-gray-700">Day {index + 1}</h4>
                {rentalDays.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeDay(index)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={day.date}
                    onChange={(e) => updateRentalDay(index, 'date', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Driver Name</label>
                  <input
                    type="text"
                    required
                    value={day.driverName}
                    onChange={(e) => updateRentalDay(index, 'driverName', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Car No.</label>
                  <input
                    type="text"
                    required
                    value={day.carNumber}
                    onChange={(e) => updateRentalDay(index, 'carNumber', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Location</label>
                  <input
                    type="text"
                    required
                    value={day.reportingPlace}
                    onChange={(e) => updateRentalDay(index, 'reportingPlace', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 mt-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Start KM</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={day.startingKm}
                    onChange={(e) => updateRentalDay(index, 'startingKm', parseInt(e.target.value) || 0)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">End KM</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={day.closingKm}
                    onChange={(e) => updateRentalDay(index, 'closingKm', parseInt(e.target.value) || 0)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Total KM</label>
                  <input
                    type="number"
                    value={day.totalKm}
                    readOnly
                    className="w-full p-2 border border-gray-300 rounded text-sm bg-gray-100 text-gray-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Start Time</label>
                  <input
                    type="time"
                    required
                    value={day.startingTime}
                    onChange={(e) => updateRentalDay(index, 'startingTime', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">End Time</label>
                  <input
                    type="time"
                    required
                    value={day.closingTime}
                    onChange={(e) => updateRentalDay(index, 'closingTime', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Hours</label>
                  <input
                    type="number"
                    step="0.1"
                    value={day.totalHours}
                    readOnly
                    className="w-full p-2 border border-gray-300 rounded text-sm bg-gray-100 text-gray-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-3 mt-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Daily Rate (₹)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={day.dailyRate}
                    onChange={(e) => updateRentalDay(index, 'dailyRate', parseFloat(e.target.value) || 0)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Extra KM Rate (₹)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={day.extraKmRate}
                    onChange={(e) => updateRentalDay(index, 'extraKmRate', parseFloat(e.target.value) || 0)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Extra Hr Rate (₹)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={day.extraHourRate}
                    onChange={(e) => updateRentalDay(index, 'extraHourRate', parseFloat(e.target.value) || 0)}
                    className="w-full p-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Day Total (₹)</label>
                  <input
                    type="number"
                    value={day.dayTotal}
                    readOnly
                    className="w-full p-2 border border-gray-300 rounded text-sm bg-green-50 font-semibold text-green-700 border-green-300"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex justify-end">
            <div className="w-full md:w-96 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-700">Total Days:</span>
                <span className="font-semibold">{rentalDays.length}</span>
              </div>
              <div className="flex justify-between text-lg font-bold border-t-2 border-green-300 pt-2">
                <span>Grand Total:</span>
                <span className="text-[#3f7a12]">₹{totals.subtotal.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-4">
          <button
            type="submit"
            className="px-6 py-2 bg-[#3f7a12] text-white rounded hover:bg-[#2d5a0c] transition-colors inline-flex items-center"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Bill
          </button>
        </div>
      </form>
    </div>
  );
};

export { CarRentalForm };

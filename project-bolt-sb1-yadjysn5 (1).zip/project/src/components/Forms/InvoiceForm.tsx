import React, { useState, useEffect } from 'react';
import { Plus, X, Save, Eye, ArrowLeft } from 'lucide-react';
import { Invoice, InvoiceItem, Company, Client } from '../../types/invoice';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { LogoUpload } from '../FileUpload/LogoUpload';
import { 
  generateInvoiceNumber, 
  calculateDaysUntilDue, 
  formatDate 
} from '../../utils/dateUtils';
import {
  calculateItemAmount,
  calculateGST,
  calculateSubtotal,
  calculateTotalGST,
  calculateTotal
} from '../../utils/calculations';
import { InvoicePreview } from '../Invoice/InvoicePreview';

interface InvoiceFormProps {
  onSubmit: (invoice: Invoice) => void;
  invoiceType?: 'gst' | 'normal' | 'proforma';
  onBack?: () => void;
}

const InvoiceForm: React.FC<InvoiceFormProps> = ({ onSubmit, invoiceType = 'gst', onBack }) => {
  const type = invoiceType;
  const [invoices, setInvoices] = useLocalStorage<Invoice[]>('invoices', []);
  const [companyDefaults] = useLocalStorage('companyDefaults', {
    name: '',
    address: '',
    phone: '',
    email: '',
    gstin: '',
    logo: ''
  });
  const [showPreview, setShowPreview] = useState(false);
  
  const [company, setCompany] = useState<Company>(companyDefaults);

  const [client, setClient] = useState<Client>({
    name: '',
    address: '',
    phone: '',
    email: '',
    gstin: ''
  });

  const [invoiceData, setInvoiceData] = useState({
    date: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    paymentMode: 'Cash',
    notes: '',
    template: 1
  });

  const [items, setItems] = useState<InvoiceItem[]>([
    {
      id: '1',
      description: '',
      quantity: 1,
      rate: 0,
      amount: 0,
      gstRate: type === 'gst' ? 18 : 0,
      gstAmount: 0
    }
  ]);

  useEffect(() => {
    updateCalculations();
  }, [items]);

  const updateCalculations = () => {
    const updatedItems = items.map(item => {
      const amount = calculateItemAmount(item.quantity, item.rate);
      const gstAmount = type === 'gst' && item.gstRate ? calculateGST(amount, item.gstRate) : 0;
      return {
        ...item,
        amount,
        gstAmount
      };
    });
    setItems(updatedItems);
  };

  const addItem = () => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      description: '',
      quantity: 1,
      rate: 0,
      amount: 0,
      gstRate: type === 'gst' ? 18 : 0,
      gstAmount: 0
    };
    setItems([...items, newItem]);
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: any) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const subtotal = calculateSubtotal(items);
    const gstTotal = type === 'gst' ? calculateTotalGST(items) : 0;
    const total = calculateTotal(subtotal, gstTotal);
    const daysUntilDue = calculateDaysUntilDue(invoiceData.dueDate);

    const invoice: Invoice = {
      id: Date.now().toString(),
      type,
      invoiceNumber: generateInvoiceNumber(type, invoices.length),
      date: invoiceData.date,
      dueDate: invoiceData.dueDate,
      daysUntilDue,
      company,
      client,
      items,
      subtotal,
      gstTotal: type === 'gst' ? gstTotal : undefined,
      total,
      paymentStatus: 'pending',
      paymentMode: invoiceData.paymentMode,
      notes: invoiceData.notes,
      template: invoiceData.template,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSubmit(invoice);
  };

  const currentInvoice: Invoice = {
    id: 'preview',
    type,
    invoiceNumber: generateInvoiceNumber(type, invoices.length),
    date: invoiceData.date,
    dueDate: invoiceData.dueDate,
    daysUntilDue: calculateDaysUntilDue(invoiceData.dueDate),
    company,
    client,
    items,
    subtotal: calculateSubtotal(items),
    gstTotal: type === 'gst' ? calculateTotalGST(items) : undefined,
    total: calculateTotal(calculateSubtotal(items), type === 'gst' ? calculateTotalGST(items) : 0),
    paymentStatus: 'pending',
    paymentMode: invoiceData.paymentMode,
    notes: invoiceData.notes,
    template: invoiceData.template,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  if (showPreview) {
    return (
      <InvoicePreview
        invoice={currentInvoice}
        onClose={() => setShowPreview(false)}
        onEdit={() => setShowPreview(false)}
      />
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 lg:p-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          {onBack && (
            <button
              onClick={onBack}
              type="button"
              className="mr-4 p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <h2 className="text-lg lg:text-2xl font-bold text-gray-800">
            Create {type === 'gst' ? 'GST Invoice' : type === 'proforma' ? 'Proforma Invoice' : 'Normal Bill'}
          </h2>
        </div>
        <button
          onClick={() => setShowPreview(true)}
          type="button"
          className="px-2 lg:px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors inline-flex items-center text-sm"
        >
          <Eye className="w-4 h-4 mr-2" />
          <span className="hidden sm:inline">Preview</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Company Information */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Company Information</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
              <input
                type="text"
                required
                value={company.name}
                onChange={(e) => setCompany({...company, name: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea
                required
                value={company.address}
                onChange={(e) => setCompany({...company, address: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="text"
                  required
                  value={company.phone}
                  onChange={(e) => setCompany({...company, phone: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={company.email}
                  onChange={(e) => setCompany({...company, email: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            {type === 'gst' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">GSTIN</label>
                <input
                  type="text"
                  required
                  value={company.gstin}
                  onChange={(e) => setCompany({...company, gstin: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}
            <div>
              <LogoUpload
                currentLogo={company.logo}
                onLogoChange={(logoUrl) => setCompany({...company, logo: logoUrl})}
                label="Company Logo (Optional)"
              />
            </div>
          </div>

          {/* Client Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Client Information</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Client Name</label>
              <input
                type="text"
                required
                value={client.name}
                onChange={(e) => setClient({...client, name: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea
                required
                value={client.address}
                onChange={(e) => setClient({...client, address: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="text"
                  required
                  value={client.phone}
                  onChange={(e) => setClient({...client, phone: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={client.email}
                  onChange={(e) => setClient({...client, email: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            {type === 'gst' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Client GSTIN (Optional)</label>
                <input
                  type="text"
                  value={client.gstin}
                  onChange={(e) => setClient({...client, gstin: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}
          </div>
        </div>

        {/* Invoice Details */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Invoice Date</label>
            <input
              type="date"
              required
              value={invoiceData.date}
              onChange={(e) => setInvoiceData({...invoiceData, date: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
            <input
              type="date"
              required
              value={invoiceData.dueDate}
              onChange={(e) => setInvoiceData({...invoiceData, dueDate: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Payment Mode</label>
            <select
              value={invoiceData.paymentMode}
              onChange={(e) => setInvoiceData({...invoiceData, paymentMode: e.target.value})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="Cash">Cash</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cheque">Cheque</option>
              <option value="UPI">UPI</option>
              <option value="Card">Card</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Template</label>
            <select
              value={invoiceData.template}
              onChange={(e) => setInvoiceData({...invoiceData, template: parseInt(e.target.value)})}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={1}>Template 1 - Modern</option>
              <option value={2}>Template 2 - Classic</option>
              <option value={3}>Template 3 - Minimal</option>
            </select>
          </div>
        </div>

        {/* Items */}
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Items</h3>
          <div className="overflow-x-auto">
            <table className="w-full border border-gray-300">
              <thead className="bg-gray-50">
                <tr>
                  <th className="border border-gray-300 p-2 text-left">Description</th>
                  <th className="border border-gray-300 p-2 text-center w-20">Qty</th>
                  <th className="border border-gray-300 p-2 text-center w-24">Rate</th>
                  {type === 'gst' && <th className="border border-gray-300 p-2 text-center w-20">GST%</th>}
                  <th className="border border-gray-300 p-2 text-center w-24">Amount</th>
                  <th className="border border-gray-300 p-2 text-center w-16">Action</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id}>
                    <td className="border border-gray-300 p-2">
                      <input
                        type="text"
                        required
                        value={item.description}
                        onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                        className="w-full p-1 border-0 focus:outline-none"
                        placeholder="Item description"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <input
                        type="number"
                        min="1"
                        required
                        value={item.quantity}
                        onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value))}
                        className="w-full p-1 border-0 focus:outline-none text-center"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        required
                        value={item.rate}
                        onChange={(e) => updateItem(item.id, 'rate', parseFloat(e.target.value))}
                        className="w-full p-1 border-0 focus:outline-none text-center"
                      />
                    </td>
                    {type === 'gst' && (
                      <td className="border border-gray-300 p-2">
                        <select
                          value={item.gstRate || 0}
                          onChange={(e) => updateItem(item.id, 'gstRate', parseInt(e.target.value))}
                          className="w-full p-1 border-0 focus:outline-none text-center"
                        >
                          <option value={0}>0%</option>
                          <option value={5}>5%</option>
                          <option value={12}>12%</option>
                          <option value={18}>18%</option>
                          <option value={28}>28%</option>
                        </select>
                      </td>
                    )}
                    <td className="border border-gray-300 p-2 text-center">
                      ₹{item.amount.toFixed(2)}
                    </td>
                    <td className="border border-gray-300 p-2 text-center">
                      <button
                        type="button"
                        onClick={() => removeItem(item.id)}
                        className="text-red-600 hover:text-red-800"
                        disabled={items.length === 1}
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <button
            type="button"
            onClick={addItem}
            className="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors inline-flex items-center"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Item
          </button>
        </div>

        {/* Totals */}
        <div className="flex justify-end">
          <div className="w-80 space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>₹{calculateSubtotal(items).toFixed(2)}</span>
            </div>
            {type === 'gst' && (
              <div className="flex justify-between">
                <span>GST Total:</span>
                <span>₹{calculateTotalGST(items).toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-lg border-t pt-2">
              <span>Total:</span>
              <span>₹{calculateTotal(calculateSubtotal(items), type === 'gst' ? calculateTotalGST(items) : 0).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
          <textarea
            value={invoiceData.notes}
            onChange={(e) => setInvoiceData({...invoiceData, notes: e.target.value})}
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={3}
            placeholder="Additional notes or terms"
          />
        </div>

        {/* Submit Button */}
        <div className="flex justify-end space-x-4">
          <button
            type="submit"
            className="px-6 py-2 bg-[#3f7a12] text-white rounded hover:bg-[#2d5a0c] transition-colors inline-flex items-center"
          >
            <Save className="w-4 h-4 mr-2" />
            Save {type === 'gst' ? 'GST Invoice' : type === 'proforma' ? 'Proforma Invoice' : 'Normal Bill'}
          </button>
        </div>
      </form>
    </div>
  );
};

export { InvoiceForm };
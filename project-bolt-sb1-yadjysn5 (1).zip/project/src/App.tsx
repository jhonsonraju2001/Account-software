import { useState } from 'react';
import { Login } from './components/Auth/Login';
import { Dashboard } from './components/Dashboard/Dashboard';
import { Header } from './components/Layout/Header';
import { Sidebar } from './components/Layout/Sidebar';
import { InvoiceForm } from './components/Forms/InvoiceForm';
import { VoucherForm } from './components/Forms/VoucherForm';
import { CarRentalForm } from './components/Forms/CarRentalForm';
import { InvoiceList } from './components/Lists/InvoiceList';
import { VoucherList } from './components/Lists/VoucherList';
import { CarRentalList } from './components/Lists/CarRentalList';
import { BalanceSheet } from './components/BalanceSheet/BalanceSheet';
import { Settings } from './components/Settings/Settings';
import { useLocalStorage } from './hooks/useLocalStorage';
import type { User } from './types/auth';
import type { Invoice } from './types/invoice';
import type { CarRentalBill } from './types/carRental';

type View =
  | 'dashboard'
  | 'invoices'
  | 'vouchers'
  | 'car-rental'
  | 'balance-sheet'
  | 'settings'
  | 'create-gst-invoice'
  | 'create-normal-bill'
  | 'create-voucher'
  | 'create-car-rental'
  | 'gst-invoice-list'
  | 'normal-bill-list'
  | 'voucher-list'
  | 'car-rental-list';

function App() {
  const [user, setUser] = useLocalStorage<User | null>('user', null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [invoices, setInvoices] = useLocalStorage<Invoice[]>('invoices', []);
  const [vouchers, setVouchers] = useLocalStorage<any[]>('vouchers', []);
  const [carRentals, setCarRentals] = useLocalStorage<CarRentalBill[]>('carRentalBills', []);

  if (!user) {
    return <Login onLogin={setUser} />;
  }

  const handleLogout = () => {
    setUser(null);
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onSectionChange={setCurrentView} />;

      case 'create-gst-invoice':
        return (
          <InvoiceForm
            onSubmit={(invoice) => {
              setInvoices([...invoices, { ...invoice, type: 'gst' }]);
              setCurrentView('gst-invoice-list');
            }}
            invoiceType="gst"
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'create-normal-bill':
        return (
          <InvoiceForm
            onSubmit={(invoice) => {
              setInvoices([...invoices, { ...invoice, type: 'normal' }]);
              setCurrentView('normal-bill-list');
            }}
            invoiceType="normal"
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'gst-invoice-list':
        return (
          <InvoiceList
            invoices={invoices.filter(inv => inv.type === 'gst')}
            onDelete={(id) => setInvoices(invoices.filter(i => i.id !== id))}
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'normal-bill-list':
        return (
          <InvoiceList
            invoices={invoices.filter(inv => inv.type === 'normal')}
            onDelete={(id) => setInvoices(invoices.filter(i => i.id !== id))}
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'create-voucher':
        return (
          <VoucherForm
            onSubmit={(voucher) => {
              setVouchers([...vouchers, voucher]);
              setCurrentView('voucher-list');
            }}
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'voucher-list':
        return (
          <VoucherList
            vouchers={vouchers}
            onDelete={(id) => setVouchers(vouchers.filter(v => v.id !== id))}
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'create-car-rental':
        return (
          <CarRentalForm
            onSubmit={(rental) => {
              setCarRentals([...carRentals, rental]);
              setCurrentView('car-rental-list');
            }}
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'car-rental-list':
        return (
          <CarRentalList
            rentals={carRentals}
            onDelete={(id) => setCarRentals(carRentals.filter(r => r.id !== id))}
            onBack={() => setCurrentView('dashboard')}
          />
        );

      case 'balance-sheet':
        return <BalanceSheet />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard onSectionChange={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        title="Dashboard"
        user={user}
        onLogout={handleLogout}
        onNotificationClick={() => {}}
        onProfileClick={() => setCurrentView('settings')}
        onMenuClick={() => setSidebarOpen(!sidebarOpen)}
      />
      <div className="flex pt-16">
        <Sidebar
          activeSection={currentView}
          onSectionChange={setCurrentView}
          user={user}
          onLogout={handleLogout}
          canAccessPremium={user?.subscriptionStatus === 'premium'}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        <main className="flex-1 p-6 lg:ml-64">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;

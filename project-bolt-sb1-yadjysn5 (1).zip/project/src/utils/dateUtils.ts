export const formatDate = (date: string | Date): string => {
  const d = new Date(date);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
};

export const calculateDaysUntilDue = (dueDate: string): number => {
  const due = new Date(dueDate);
  const today = new Date();
  const timeDiff = due.getTime() - today.getTime();
  return Math.ceil(timeDiff / (1000 * 3600 * 24));
};

export const generateInvoiceNumber = (type: string, count: number): string => {
  const prefix = type === 'gst' ? 'GST' : type === 'proforma' ? 'PF' : 'INV';
  return `${prefix}-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
};

export const generateVoucherNumber = (type: string, count: number): string => {
  const prefix = type === 'payment' ? 'PV' : type === 'advance' ? 'AV' : 'RV';
  return `${prefix}-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
};
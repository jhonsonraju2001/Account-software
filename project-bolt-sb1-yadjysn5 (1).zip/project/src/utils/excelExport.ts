import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Invoice, PaymentVoucher } from '../types/invoice';
import { formatDate } from './dateUtils';

export const exportInvoicesToExcel = (invoices: Invoice[], filename: string = 'invoices') => {
  const worksheetData = invoices.map(invoice => ({
    'Invoice Number': invoice.invoiceNumber,
    'Type': invoice.type.toUpperCase(),
    'Date': formatDate(invoice.date),
    'Due Date': formatDate(invoice.dueDate),
    'Days Until Due': invoice.daysUntilDue,
    'Client Name': invoice.client.name,
    'Client Email': invoice.client.email,
    'Client Phone': invoice.client.phone,
    'Client Address': invoice.client.address,
    'Client GSTIN': invoice.client.gstin || '',
    'Subtotal': invoice.subtotal,
    'GST Total': invoice.gstTotal || 0,
    'Total Amount': invoice.total,
    'Payment Status': invoice.paymentStatus.replace('_', ' ').toUpperCase(),
    'Payment Mode': invoice.paymentMode,
    'Notes': invoice.notes,
    'Created At': formatDate(invoice.createdAt)
  }));

  const worksheet = XLSX.utils.json_to_sheet(worksheetData);
  const workbook = XLSX.utils.book_new();
  
  // Set column widths
  const colWidths = [
    { wch: 15 }, // Invoice Number
    { wch: 10 }, // Type
    { wch: 12 }, // Date
    { wch: 12 }, // Due Date
    { wch: 12 }, // Days Until Due
    { wch: 20 }, // Client Name
    { wch: 25 }, // Client Email
    { wch: 15 }, // Client Phone
    { wch: 30 }, // Client Address
    { wch: 15 }, // Client GSTIN
    { wch: 12 }, // Subtotal
    { wch: 12 }, // GST Total
    { wch: 12 }, // Total Amount
    { wch: 15 }, // Payment Status
    { wch: 15 }, // Payment Mode
    { wch: 30 }, // Notes
    { wch: 15 }  // Created At
  ];
  worksheet['!cols'] = colWidths;

  XLSX.utils.book_append_sheet(workbook, worksheet, 'Invoices');
  
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  
  saveAs(data, `${filename}-${new Date().toISOString().split('T')[0]}.xlsx`);
};

export const exportVouchersToExcel = (vouchers: PaymentVoucher[], filename: string = 'vouchers') => {
  const worksheetData = vouchers.map(voucher => ({
    'Voucher Number': voucher.voucherNumber,
    'Type': voucher.type.toUpperCase(),
    'Date': formatDate(voucher.date),
    'Client/Payee Name': voucher.client.name,
    'Client Email': voucher.client.email,
    'Client Phone': voucher.client.phone,
    'Client Address': voucher.client.address,
    'Payment Amount': voucher.amount,
    'Total Amount': voucher.totalAmount || '',
    'Advance Payment': voucher.advancePayment || '',
    'Remaining Balance': voucher.remainingBalance || '',
    'Payment Mode': voucher.paymentMode,
    'Reference': voucher.reference,
    'Description': voucher.description,
    'Status': voucher.status.toUpperCase(),
    'Created At': formatDate(voucher.createdAt)
  }));

  const worksheet = XLSX.utils.json_to_sheet(worksheetData);
  const workbook = XLSX.utils.book_new();
  
  // Set column widths
  const colWidths = [
    { wch: 15 }, // Voucher Number
    { wch: 12 }, // Type
    { wch: 12 }, // Date
    { wch: 20 }, // Client Name
    { wch: 25 }, // Client Email
    { wch: 15 }, // Client Phone
    { wch: 30 }, // Client Address
    { wch: 12 }, // Payment Amount
    { wch: 12 }, // Total Amount
    { wch: 12 }, // Advance Payment
    { wch: 12 }, // Remaining Balance
    { wch: 15 }, // Payment Mode
    { wch: 20 }, // Reference
    { wch: 30 }, // Description
    { wch: 12 }, // Status
    { wch: 15 }  // Created At
  ];
  worksheet['!cols'] = colWidths;

  XLSX.utils.book_append_sheet(workbook, worksheet, 'Vouchers');
  
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  
  saveAs(data, `${filename}-${new Date().toISOString().split('T')[0]}.xlsx`);
};

export const exportItemizedInvoiceToExcel = (invoice: Invoice) => {
  // Invoice details sheet
  const invoiceData = [{
    'Invoice Number': invoice.invoiceNumber,
    'Type': invoice.type.toUpperCase(),
    'Date': formatDate(invoice.date),
    'Due Date': formatDate(invoice.dueDate),
    'Client Name': invoice.client.name,
    'Client Email': invoice.client.email,
    'Total Amount': invoice.total,
    'Payment Status': invoice.paymentStatus.replace('_', ' ').toUpperCase()
  }];

  // Items sheet
  const itemsData = invoice.items.map((item, index) => ({
    'S.No': index + 1,
    'Description': item.description,
    'Quantity': item.quantity,
    'Rate': item.rate,
    'Amount': item.amount,
    'GST Rate': item.gstRate || 0,
    'GST Amount': item.gstAmount || 0,
    'Total': item.amount + (item.gstAmount || 0)
  }));

  const workbook = XLSX.utils.book_new();
  
  const invoiceSheet = XLSX.utils.json_to_sheet(invoiceData);
  const itemsSheet = XLSX.utils.json_to_sheet(itemsData);
  
  XLSX.utils.book_append_sheet(workbook, invoiceSheet, 'Invoice Details');
  XLSX.utils.book_append_sheet(workbook, itemsSheet, 'Items');
  
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  
  saveAs(data, `${invoice.invoiceNumber}-details.xlsx`);
};
import { InvoiceItem } from '../types/invoice';

export const calculateItemAmount = (quantity: number, rate: number): number => {
  return quantity * rate;
};

export const calculateGST = (amount: number, gstRate: number): number => {
  return (amount * gstRate) / 100;
};

export const calculateSubtotal = (items: InvoiceItem[]): number => {
  return items.reduce((sum, item) => sum + item.amount, 0);
};

export const calculateTotalGST = (items: InvoiceItem[]): number => {
  return items.reduce((sum, item) => sum + (item.gstAmount || 0), 0);
};

export const calculateTotal = (subtotal: number, gstTotal: number = 0): number => {
  return subtotal + gstTotal;
};